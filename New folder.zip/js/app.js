            var db;
            var module = ons.bootstrap('my-app', ['onsen','ngMessages']);
		//	var appurl ='http://192.168.43.165:8092/CCTNSWS/CCTNSMobilityService/registrations';
	
//	 var appurl ='http://192.168.43.230:8080/CCTNSWS/CCTNSMobilityService/registrations';
	//  	var appurl ='http://10.33.248.178:8080/CCTNSWS/CCTNSMobilityService/registrations';
	//	var appurl ='http://10.33.248.161:8080/CCTNSWS/CCTNSMobilityService/registrations';
 		var appurl ='http://210.212.145.104:8080/CCTNSWS/CCTNSMobilityService/registrations';
		
		//	var appurl ='http://164.100.196.55:8080/CCTNSWS/CCTNSMobilityService/registrations';//live_dc
		

 //var appurl ='http://164.100.196.55:8080/CCTNSWS/CCTNSMobilityService/registrations';

//	var appurl ='http://210.212.145.104:8080/CCTNSWS/CCTNSMobilityService/registrations';


			
//            module.config([
//                '$stateProvider', function ($stateProvider) {
//                    $stateProvider.state('view', {
//                        url: "/view/:index", //NOTE: :index is how you use $stateParams later on.
//                        views: {
//                            'home-tab': {
//                                templateUrl: "view.html",
//                                controller: 'ShowController'
//                            }
//                        }
//                    });
//                }
//            ]);

/*module.run(function($rootScope,$document) 
{
  var d = new Date();
  var n = d.getTime();  //n in ms
  
 
    $rootScope.idleEndTime = n+(5*60*1000); //set end time to 20 min from now
    $document.find('body').on('mousemove keydown DOMMouseScroll mousewheel mousedown touchstart', checkAndResetIdle); //monitor events

    function checkAndResetIdle() //user did something
    {
      var d = new Date();
      var n = d.getTime();  //n in ms

        if (n>$rootScope.idleEndTime)
        {
            $document.find('body').off('mousemove keydown DOMMouseScroll mousewheel mousedown touchstart'); //un-monitor events

            //$location.search('IntendedURL',$location.absUrl()).path('/login'); //terminate by sending to login page
          //  document.location.href = 'https://whatever.com/myapp/#/login';
		 	window.localStorage.removeItem("userid");
			window.localStorage.clear(); 
				
            alert('Session ended due to inactivity');
			window.location.reload(true);
        }
        else
        {
            $rootScope.idleEndTime = n+(5*60*1000); //reset end time
        }
    }
});
*/
module.controller('MainController', function($scope,$http,$window) {
											 
											 
  ons.ready(function() {
					 
	modal.show();
    setTimeout('modal.hide()', 3000);
 
	
	 try {
               
			   
			  
			   
			   if(window.localStorage["userid"]!= undefined)
			   {
			         
					  				  
						$scope.oshow=true;
						$scope.pshow=true;
						$scope.lshow=false;
						$scope.rshow=false;
						$scope.cpshow=true;
			   }
			   else
			   {
			   			
					 $scope.oshow=false;
					  $scope.lshow=true;
					  $scope.rshow=true;
					  $scope.pshow=false;
					   $scope.cpshow=false;
			   }
				 
                } catch (e) {
                    alert(e);
                }
	
					 

  });
  
  $scope.checkuserlogin = function (condision) { 
				   
				   
				 
				if(window.localStorage["userid"]!= undefined)
			   {
			         
					  		  if(condision=="complaint")
						  {
							myNavigator.pushPage('complaint.html', {
							animation: 'slide'
							 
							});
						  }
						  	else if(condision=="complaintnew")
						  {
							myNavigator.pushPage('complaint_new.html', {
							animation: 'slide'
							 
							});
						  }
						  
						   else if(condision=="searcharticle")
						  {
							myNavigator.pushPage('search.html', {
							animation: 'slide'
							 
							});
						  }
						  
						    else if(condision=="viewcomplaint")
						  {
						    myNavigator.pushPage('acknowledge.html', {
									animation: 'slide'
									 
									});
						
						  }
						    else if(condision=="incidentreport")
						  {
						    myNavigator.pushPage('citizentips.html', {
									animation: 'slide'
									 
									});
						
						  }
						  
						   else if(condision=="incident")
						  {
							myNavigator.pushPage('incident.html', {
							animation: 'slide'
							 
							});
						  }
						  
/*						   else if(condision=="download")
						  {
							myNavigator.pushPage('download.html', {
							animation: 'slide'
							 
							});
						  }
*/						   else if(condision=="sos")
						  {
							
								/* myNavigator.pushPage('sos.html', {
									animation: 'slide'
									 
									});*/
								var id =   window.localStorage["userid"];
						$http({
                        method: 'POST',
                        url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/getLoginStatus',
                       data: {UserID:id},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						//	alert(serverResponse);
						    var x =   JSON.parse(serverResponse);  
							
							if(x.status=='T')
							{
								 myNavigator.pushPage('sossend.html', {
									animation: 'slide'
									 
									});
								
							}
							else
							{
								 myNavigator.pushPage('sos.html', {
									animation: 'slide'
									 
									});
								
								
							}
						 // alert(x);
					//	  alert(JSON.stringify(x));
						  
                        //  $scope.result = x;
                     //   $scope.newsitems = x; 
                        
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
						  }			  
						 
			   }
			   
			   else
			   {
			   	  if(condision=="complaint")
						  {
						    myNavigator.pushPage('login.html', {
							animation: 'slide'
							 
							});
						  }
						  
						  	else if(condision=="complaintnew")
						  {
							myNavigator.pushPage('login.html', {
							animation: 'slide'
							 
							});
						  }
						  
						 else if(condision=="incident")
						  {
						    myNavigator.pushPage('login.html', {
							animation: 'slide'
							 
							});
						  }
						  
						   else if(condision=="sos")
						  {
						    myNavigator.pushPage('login.html', {
									animation: 'slide'
									 
									});
						
						  }
						   else if(condision=="viewcomplaint")
						  {
						    myNavigator.pushPage('login.html', {
									animation: 'slide'
									 
									});
						
						  }
						    else if(condision=="incidentreport")
						  {
						    myNavigator.pushPage('login.html', {
									animation: 'slide'
									 
									});
						
						  }
						  /*else if(condision=="download")
						  {
						    myNavigator.pushPage('login.html', {
							animation: 'slide'
							 
							});
						  }*/
			   }
				  
				  
                 }
  
                  $scope.logout = function () { 
				 
				window.localStorage.removeItem("userid");
				window.localStorage.clear(); 
				window.location.reload(true);
                
                }
				
				$scope.redirectToGoogle = function () {
                
				       $window.open('http://www.simhasthujjain.in/', '_blank');
				}
				
				$scope.redirectToMPPolice = function () {
                
				       $window.open('http://mppolice.gov.in/', '_blank');
				}
				$scope.redirectToVahanSamanvay = function () {
                
				       $window.open('http://ncrb.gov.in/VahanSamanvay/Motor_Vehicle.htm', '_blank');
				}
				$scope.redirectToMPRTO = function () {
                
				       $window.open('http://www.mptransport.org/', '_blank');
				}
				
				 
  
});

 module.controller('ProfileController', function ($scope,$http) {
	menu.close();
			
			  try {
                    
                //    var id = $scope.st; // Will return "value1"
				var id = 	window.localStorage["userid"];
			//	alert(id);
                   $scope.userdeatils ={
					loginId:id
					};
					
					var perameter = JSON.stringify($scope.userdeatils);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/userProfileDisplay',
                        data: perameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                      //   alert(JSON.stringify(serverResponse));
						$scope.users = serverResponse.userProfileResponseBean;						
                        
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
								
				 
                
			 
            });
 
 module.controller('SOSNewController', function ($scope,$http,$window) {
	 try {
				
					/*gpsDetect.checkGPS(onGPSSuccess, onGPSError);
		
		
		function onGPSSuccess(on) {
			if (on)
			{ 
			//alert("GPS is enabled");
			}
			else{ 
			
			 
				var r = confirm("Start GPS Services ");
				if (r == true) {
		 	gpsDetect.switchToLocationSettings(onSwitchToLocationSettingsSuccess, onSwitchToLocationSettingsError);
			
		//	cordova.plugins.diagnostic.switchToLocationSettings();
				
				} else {
				
				}
			
			}
		}
		
		function onGPSError(e) {
			alert("Error : "+e);
		}
		
	

		function onSwitchToLocationSettingsSuccess() {
		 window.location.reload(true);
		 

		}

		function onSwitchToLocationSettingsError(e) {
		//	alert("Error : "+e);
		 window.location.reload(true);
		}*/
		
		cordova.plugins.locationAccuracy.request(function (success){
						 
				//	console.log("Successfully requested accuracy: "+success.message);
					
				//alert('hi');
				
				 $window.navigator.geolocation.getCurrentPosition(function(position){
				var lat1= position.coords.latitude;
				var lng1 = position.coords.longitude;
				  
			//	 alert(lat1+lng1);
				//$scope.lat1 = lat1;
				//$scope.lng1 = lng1;	
				//$scope.$apply();
				var address="";
					var geocoder = new google.maps.Geocoder();
var latitude = lat1;
var longitude = lng1;
var latLng = new google.maps.LatLng(latitude,longitude);
geocoder.geocode({       
        latLng: latLng     
        }, 
        function(responses) 
        {     
           if (responses && responses.length > 0) 
           {        
                address=responses[0].formatted_address; 
				//alert(address);
				$scope.addressnew = address;
				 $scope.latti = latitude;
				 $scope.langi = longitude;
				$scope.$apply();
           } 
           else 
           {       
             alert('Not getting Any address for given latitude and longitude.');     
           }   
        }
);
          
			///	 alert(address);
				
				
			   													 
				});
                   var page = myNavigator.getCurrentPage();
                //    var id = page.options.id; // Will return "value1"
					var id = 	window.localStorage["userid"];
					 
				//	 alert(id);
                    $http({
                        method: 'POST',
                        url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/getLoginStatus',
                       data: {UserID:id},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						//	alert(serverResponse);
						    var x =   JSON.parse(serverResponse);  
						 // alert(x);
					//	  alert(JSON.stringify(x));
						  
                        //  $scope.result = x;
                     //   $scope.newsitems = x; 
                        $scope.sosdata = x;
                        $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                
				
					
					}, function (error){
					console.error("Accuracy request failed: error code="+error.code+"; error message="+error.message);
					if(error.code !== cordova.plugins.locationAccuracy.ERROR_USER_DISAGREED)
					{
						if(window.confirm("Failed to automatically set Location Mode to 'High Accuracy'. Would you like to switch to the Location Settings page and do this manually?"				))
					{
					cordova.plugins.diagnostic.switchToLocationSettings();
					}
					}
					}, cordova.plugins.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY);
				
		
	}
				catch (e) {
                    alert(e);
                }
			
			/*try {
				//alert('hi');
				
				 $window.navigator.geolocation.getCurrentPosition(function(position){
				var lat1= position.coords.latitude;
				var lng1 = position.coords.longitude;
				  
			//	 alert(lat1+lng1);
				//$scope.lat1 = lat1;
				//$scope.lng1 = lng1;	
				//$scope.$apply();
				var address="";
					var geocoder = new google.maps.Geocoder();
var latitude = lat1;
var longitude = lng1;
var latLng = new google.maps.LatLng(latitude,longitude);
geocoder.geocode({       
        latLng: latLng     
        }, 
        function(responses) 
        {     
           if (responses && responses.length > 0) 
           {        
                address=responses[0].formatted_address; 
				//alert(address);
				$scope.addressnew = address;
				 
				$scope.$apply();
           } 
           else 
           {       
             alert('Not getting Any address for given latitude and longitude.');     
           }   
        }
);
          
			///	 alert(address);
				
				
			   													 
				});
                   var page = myNavigator.getCurrentPage();
                //    var id = page.options.id; // Will return "value1"
					var id = 	window.localStorage["userid"];
					 
				//	 alert(id);
                    $http({
                        method: 'POST',
                        url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/getLoginStatus',
                       data: {UserID:id},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						//	alert(serverResponse);
						    var x =   JSON.parse(serverResponse);  
						 // alert(x);
					//	  alert(JSON.stringify(x));
						  
                        //  $scope.result = x;
                     //   $scope.newsitems = x; 
                        $scope.sosdata = x;
                        $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }*/
				
			 
			 
            });
 
 
 
 
 		 module.controller('SOSController', function ($scope,$http) {
														 
				   
			$scope.phonebook = function (phoneval) {
				 
					 
                navigator.contacts.pickContact(function(contact){
														
				var contactn = contact.phoneNumbers[0].value;										
														
					if(phoneval==1)
				   {
					   
					   document.getElementById("contact"+phoneval).value = contactn;
					   document.getElementById("contact"+phoneval).focus(); 
					    document.getElementById(contactnew).value = contactn;
					   
				   }
				   else if(phoneval==2)
				   {
					     
					   document.getElementById("contact"+phoneval).value = contactn;
					   document.getElementById("contact"+phoneval).focus(); 
				   }
				   else if(phoneval==3)
				   {
					      
					   document.getElementById("contact"+phoneval).value = contactn;
					   document.getElementById("contact"+phoneval).focus(); 
				   }
				   else if(phoneval==4)
				   {    
					   document.getElementById("contact"+phoneval).value = contactn;
					   document.getElementById("contact"+phoneval).focus(); 
				   }
				   else if(phoneval==5)
				   {
					     
					   document.getElementById("contact"+phoneval).value = contactn;
					   document.getElementById("contact"+phoneval).focus(); 
				   }									
				   
				 
				},function(err){
				console.log('Error: ' + err);
				});
                }
				
		  $scope.save = function (form) {
				  
				var x1 = "";
				var x2 = "";
				var x3 = "";
				var x4 = "";
				var x5 = "";
			  
			      x1 = document.getElementById("contact1").value;
				  x2 = document.getElementById("contact2").value;
				  x3 = document.getElementById("contact3").value;
				  x4 = document.getElementById("contact4").value;
				  x5 = document.getElementById("contact5").value;
				 
             
			    var id = 	window.localStorage["userid"];
			  
                    
                    $http({
                        method: 'POST',
                        url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/InsertSOSDeetails',
                        data: {Contact1:x1,Contact2:x2,Contact3:x3,Contact4:x4,Contact5:x5,PreMsg:$scope.premsg,UserID:id},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						//  alert(serverResponse+'vikku');
					    //  uid = serverResponse.sos_id;
						//  $scope.userid = uid;
                           ons.notification.alert({
							message: 'Contacts Saved Successfully'
							});
						//	 window.location.reload(true);
					   
                     			myNavigator.pushPage('sossend.html', {
										animation: 'slide',
										id:id
										
										});
					   
							
                        
                    }).error(function (serverResponse, status, headers, config) {
						
						
                    });
               
					
                }
				
				  
			 
            });
     
            module.controller('AppController', function ($scope) {
			
			
			 
            });
			 
			
			
		 
			
			
			
			module.controller('NewsController', function ($scope,$http) {					 									  
														  
				$scope.open = function (ds,ps,st) {				
			//	 alert(st);
                    myNavigator.pushPage('newsview.html', {
                        animation: 'slide',
                        dname: ds,
						psname:ps,
						storyname:st
                    });
                }
				$scope.sendval = {				
					
					PageNumber: '',				
					PageSize: ''				 
					};
			
			 try {
                  //  alert('hi');
               //     var id = $scope.st; // Will return "value1"
                    $http({
                        method: 'POST',
                        url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/getSuccessStories',
						 data: {PageNumber: '',	PageSize: ''},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 var x =   JSON.parse(serverResponse);
			 //  alert(serverResponse);
						    var x =   JSON.parse(serverResponse);  
						 // alert(x);
					//	  alert(JSON.stringify(x));
						  
                        //  $scope.result = x;
                        $scope.newsitems = x;
                        $scope.$apply();
                        modal.hide();
						funchk();
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
				
				/*function funchk()
				{
					alert('hi');
					var t = $scope.newsitems;
					alert(t.length);
					for(var i = 0; i <t.length; i++)
					{
						  if(t[i].SucessStoryID == 446)
						  {
							alert(t[i].SucessStoryID);
						  }
							
					}
				}*/
				
			 
            });
			
			
			
			   module.controller('NewsViewController', function ($scope, $http) {                  	
                try { 
				   
				   
                    var page = myNavigator.getCurrentPage();
                    var dist = page.options.dname; // Will return "value1"
					var station = page.options.psname; // Will return "value2"
					 var storyid = page.options.storyname; // Will return "value3"
					// alert(dist+station+title);
                        $http({
                        method: 'POST',
                        url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/getSuccessStoriesDetail',
						 data: {DistrictName: dist,	PStationName: station,SucessStoryID:storyid},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					
				    	var x =   JSON.parse(serverResponse);
					
					  $scope.newsitemst = x[0].StoryTitle;
					   $scope.newsitemsd = x[0].StoryDetails;
                        $scope.$apply();
                       						
                      
                        modal.hide();
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
            });
			   
			   
			     module.controller('HospitalSearchController', function ($scope,$http) {
																	   
						 
			$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					
					$scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                     //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
				$scope.searchhospital = function () {		
				$scope.searchpera = {
					districtCd: $scope.dist,
					langCd:99
					
					};
					 
					var parameter2 = JSON.stringify($scope.searchpera);
                   modal.show();
                   $http({
                        method: 'POST',
                        url: appurl+'/masterHospitalList',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {                        
                        if (serverResponse) {	
					//	alert(JSON.stringify(serverResponse));
						$scope.hospitals = serverResponse.hospitalResponseBean;
						  $scope.$apply();
						  modal.hide();
                        
						 
                        }
						else {
							modal.hide();
                           ons.notification.alert({
							message: 'No Data Found!'
							});
							
                        }
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
																	   
				});
			
			  module.controller('PageController', function ($scope) {
			
			
			 
            });
			 /*module.controller('MapController', function ($scope,$window) {
				$window.navigator.geolocation.getCurrentPosition(function(position){
				var lat= position.coords.latitude;
				var lng = position.coords.longitude;
				  
				$scope.lat = lat;
				$scope.lng = lng;				
				
				$scope.$apply();	 
				   mapCenter = new google.maps.LatLng($scope.lat,$scope.lng),
                 myOptions = {
                     zoom:10,
                     mapTypeId: google.maps.MapTypeId.ROADMAP,
                     center: mapCenter,
                 },
                map = new google.maps.Map(document.getElementById("map_canvas"), myOptions),
                  
                 marker = new google.maps.Marker({
                     position: new google.maps.LatLng($scope.lat,$scope.lng),
                     map: map,
                     title:"Current Location!"
                     })
			   													 
				});
			  										 
			 
            });*/
			 
			    module.controller('sosmap', function ($scope,$window,$http) {
													  
				
			
			    var watchID = navigator.geolocation.watchPosition(onSuccess, onError, { frequency: 3000 });
			 
				function onSuccess(position) {
					
					var lat = position.coords.latitude;
					var lng = position.coords.longitude;
					
					
					 mapCenter = new google.maps.LatLng(lat,lng),
                 myOptions = {
                     zoom:10,
    panControl:true,
    zoomControl:true,
    mapTypeControl:true,
    scaleControl:true,
    streetViewControl:false,
    overviewMapControl:true,
    rotateControl:true, 
                     mapTypeId: google.maps.MapTypeId.HYBRID,
                     center: mapCenter,
                 },
                map = new google.maps.Map(document.getElementById("map_canvas_new"), myOptions),
                 marker = new google.maps.Marker({
                     position: new google.maps.LatLng(lat,lng),
                     map: map,
					 animation:google.maps.Animation.BOUNCE,
                     title:"Current Location!"
                     })
				 
				 

				
				 
				}
				
				// onError Callback receives a PositionError object
				//
				function onError(error) {
				alert('code: '    + error.code    + '\n' +
				'message: ' + error.message + '\n');
				}
				

				// Options: retrieve the location every 3 seconds
				//
				
			
			
			
			});
			
			 
			  module.controller('MapController', function ($scope,$window,$http) {
			 
				try {
					
					cordova.plugins.locationAccuracy.request(function (success){
						 
					console.log("Successfully requested accuracy: "+success.message);
					 $window.navigator.geolocation.getCurrentPosition(function(position){
				var lat= position.coords.latitude;
				var lng = position.coords.longitude;
		// 	alert(lat);
		// 	alert(lng);
				//  alert('hi');
			//	$scope.lat = lat;
			//	$scope.lng = lng;	
			//alert($scope.lat+$scope.lng);
			//	$scope.$apply();
				
				
                   $http({
                        method: 'POST',
                      //  url: 'http://182.72.131.182:8080/api/SOSLogin/getLatLongDistance',
						  url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/getLatLongDistance',
						 data: {Lat:lat,Long:lng},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 var x =   JSON.parse(serverResponse);
					//alert('hi');
					//   alert(serverResponse);
						                   
                        if (serverResponse) {	
						 var x =   JSON.parse(serverResponse); 
						// alert(x);
						lati = x.Lat;
						longi = x.Long;	
					//	alert(lati);
					//	alert(longi);
						dis = x.distance;
					 
					//	address = x.PS
						
					//	$scope.lati = lati;
				    //    $scope.longi = longi;						
						$scope.dist = dis+' KM';
				   //     $scope.addr = address;

					//	$scope.lati = lati;
				      //  $scope.longi = longi;						
					//	$scope.dist = dis;
				        $scope.addr = x.PS;
						$scope.pnumber = x.PS_Landlin;
						$scope.$apply();

						 
							 
					 mapCenter = new google.maps.LatLng(lati,longi),
                 myOptions = {
                     zoom:15,
    panControl:true,
    zoomControl:true,
    mapTypeControl:true,
    scaleControl:true,
    streetViewControl:false,
    overviewMapControl:true,
    rotateControl:true, 
                     mapTypeId: google.maps.MapTypeId.TERRAIN,
                     center: mapCenter,
                 },
                map = new google.maps.Map(document.getElementById("map_canvas"), myOptions),
                 marker = new google.maps.Marker({
                     position: new google.maps.LatLng(lati,longi),
                     map: map,
					 animation:google.maps.Animation.BOUNCE,
                     title:"Current Location!"
                     })
				 
				

  
						
						



						
                        } else {
                          //  alert("Sorry thana not found");
                        }
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);					 
					     
					 
                    });
				
				
			   													 
				});
					
					}, function (error){
					console.error("Accuracy request failed: error code="+error.code+"; error message="+error.message);
					if(error.code !== cordova.plugins.locationAccuracy.ERROR_USER_DISAGREED)
					{
						if(window.confirm("Failed to automatically set Location Mode to 'High Accuracy'. Would you like to switch to the Location Settings page and do this manually?"				))
					{
					cordova.plugins.diagnostic.switchToLocationSettings();
					}
					}
					}, cordova.plugins.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY);
				
				//	gpsDetect.checkGPS(onGPSSuccess, onGPSError);
		
		
		/*function onGPSSuccess(on) {
			if (on)
			{ 
			//alert("GPS is enabled");
			}
			else{ 
			
			 
				var r = confirm("Start GPS Services ");
				if (r == true) {
		 	gpsDetect.switchToLocationSettings(onSwitchToLocationSettingsSuccess, onSwitchToLocationSettingsError);
			
		//	cordova.plugins.diagnostic.switchToLocationSettings();
				
				} else {
				
				}
			
			}
		}
		
		function onGPSError(e) {
			alert("Error : "+e);
		}
		
	

		function onSwitchToLocationSettingsSuccess() {
	 	 window.location.reload(true);
		//$window.location.href = 'location.html'; 
		
		// $window.open('location.html', '_self')
		
		}

		function onSwitchToLocationSettingsError(e) {
		//	alert("Error : "+e);
		  window.location.reload(true);
	//	$window.location.href = 'location.html'; 
	//	$window.open('location.html', '_self')
		}*/
	}
				catch (e) {
                    alert(e);
                }
			  			
				
				  try {
					
					 /* $window.navigator.geolocation.getCurrentPosition(function(position){
				var lat= position.coords.latitude;
				var lng = position.coords.longitude;
		// 	alert(lat);
		// 	alert(lng);
				//  alert('hi');
			//	$scope.lat = lat;
			//	$scope.lng = lng;	
			//alert($scope.lat+$scope.lng);
			//	$scope.$apply();
				
				
                   $http({
                        method: 'POST',
                      //  url: 'http://182.72.131.182:8080/api/SOSLogin/getLatLongDistance',
						  url: 'http://164.100.196.144/mppoliceapp/api/SOSLogin/getLatLongDistance',
						 data: {Lat:lat,Long:lng},
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 var x =   JSON.parse(serverResponse);
					//alert('hi');
					//   alert(serverResponse);
						                   
                        if (serverResponse) {	
						 var x =   JSON.parse(serverResponse); 
						// alert(x);
						lati = x.Lat;
						longi = x.Long;	
					//	alert(lati);
					//	alert(longi);
						dis = x.distance;
					 
					//	address = x.PS
						
					//	$scope.lati = lati;
				    //    $scope.longi = longi;						
						$scope.dist = dis+' KM';
				   //     $scope.addr = address;

					//	$scope.lati = lati;
				      //  $scope.longi = longi;						
					//	$scope.dist = dis;
				        $scope.addr = x.PS;
						$scope.pnumber = x.PS_Landlin;
						$scope.$apply();

						 
							 
					 mapCenter = new google.maps.LatLng(lati,longi),
                 myOptions = {
                     zoom:15,
    panControl:true,
    zoomControl:true,
    mapTypeControl:true,
    scaleControl:true,
    streetViewControl:false,
    overviewMapControl:true,
    rotateControl:true, 
                     mapTypeId: google.maps.MapTypeId.TERRAIN,
                     center: mapCenter,
                 },
                map = new google.maps.Map(document.getElementById("map_canvas"), myOptions),
                 marker = new google.maps.Marker({
                     position: new google.maps.LatLng(lati,longi),
                     map: map,
					 animation:google.maps.Animation.BOUNCE,
                     title:"Current Location!"
                     })
				 
				

  
						
						



						
                        } else {
                          //  alert("Sorry thana not found");
                        }
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);					 
					     
					 
                    });
				
				
			   													 
				});*/} catch (e) {
                    alert(e);
                }
			  										 
			 
            });
			
			 module.controller('DashboardController', function ($scope,$window) {
																	
              														
            });
			  

            module.controller('PageController', function ($scope,$http,$timeout) {
			
		
                
            });

 

            function tandc() {
			
                ons.createDialog('dialogcontent.html').then(function (dialog) {
                    dialog.show();
                });
            }
			
			 
        
            module.controller('DirController', function ($scope, $http) {
                
               $scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
					//	alert(e);
					}
					
					 $scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                //      alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
				
				 $scope.directory = function () {
				 
				
                  
				   
				   	$scope.searchpera = {				
					policeStationCd: $scope.thanadist,
					districtCd: $scope.dist,
					langCd:99
					};
					 
					var parameter = JSON.stringify($scope.searchpera);
				   
				     modal.show();
				  
                    $http({
                        method: 'POST',
                        url: appurl+'/policeDirectory',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         if (serverResponse) {	
				//	alert(JSON.stringify(serverResponse));
						$scope.thanausers = serverResponse.policeDirectoryResponseBean;
						  $scope.$apply();
						  modal.hide();
                        
						 
                        }
						else {
							modal.hide();
                           ons.notification.alert({
							message: 'No Data Found!'
							});
							
                        }
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
						// $scope.show=false;
                    });
                }				
				 
       
            });


 
 
        
			
		  module.controller('OtpController', function ($scope, $http) {
			     
				 
				 try {
                    var page = myNavigator.getCurrentPage();
                    var mobile = page.options.mobile; // Will return "value1"
					
					$scope.mobile = mobile;
					
					$scope.$apply(); 
					 
                } catch (e) {
                    alert(e);
                }
				   $scope.loginotp = function (form) {
				 if ($scope[form].$valid) {	
                  
                    $http({
                        method: 'POST',
                        url: 'http://localhost/rest/loginotp',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},			
				        data: {username: $scope.mobile,otp: $scope.otp},
                    }).success(function (serverResponse, status, headers, config) {	
                        if (serverResponse) {						
						uid = serverResponse.id;						 
						$scope.userid = uid;	
						$scope.oshow=true;
					    $scope.lshow=false;
					    $scope.rshow=false;
						$scope.pshow=true;
						$scope.$apply();
						
						window.location.reload(true);
					   
                        } else {
                            alert("Sorry login faild");
                        }
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 else
				 {
				 	 $scope.showMsgs = true;
				 }
                }
			   
                
            });
			
			 module.controller('LoginController', function ($scope, $http) {
			     
				 menu.close();
				
				  $scope.ForgotPassword = function () {
					  
					    myNavigator.pushPage('forgotpssword.html', {
                        animation: 'slide'
                    });
				  }
			   
                $scope.login = function (form) {
					
					
				 if ($scope[form].$valid) {	
				 
				 	 modal.show();
					$scope.login = {				
					
					strLoginId: $scope.loginid,				
					strPassword: $scope.password,
					langCd:99
					};
					
					var parameter = JSON.stringify($scope.login);
                  
                     $http({
                        method: 'POST',
                        url: appurl+'/validateUser',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {					
						 
                        $scope.result = serverResponse.validateUserResponseBean;
						modal.hide();
							// alert(JSON.stringify($scope.result));
  						//	alert($scope.result.bStatus);
							if($scope.result.loginStatusCode=='S')
							{
								 
					
								alert("Login Successfull");
							
								window.localStorage["userid"] =  $scope.loginid;
								 
								 
								
								window.location.reload(true);
							}
							else if($scope.result.loginStatusCode=='U')
							{
								alert($scope.result.loginStatus);
								$scope.loginid="";
								$scope.password="";
								
							}
							else if($scope.result.loginStatusCode=='P')
							{
								alert($scope.result.loginStatus);
								$scope.loginid="";
								$scope.password="";
							}
							else if($scope.result.loginStatusCode=='D')
							{
								alert($scope.result.loginStatus);
								$scope.loginid="";
								$scope.password="";
							}
							
					   
                          
                    }).error(function (serverResponse, status, headers, config) {
                        alert("Connection Problem");
						$scope.loginid="";
						$scope.password="";
                    });
				 }
				 else
				 {
				 	 $scope.showMsgs = true;
				 }
                }
            });

			

            module.controller('ViewController', function ($scope, $http) {
                modal.show();
                try {
                    var page = myNavigator.getCurrentPage();
                    var id = page.options.id; // Will return "value1"
                    $http({
                        method: 'GET',
                        url: 'http://localhost/appcityzen/index.php/site/dir/id/' + id,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                        $scope.items = serverResponse;
                        $scope.$apply();
                        modal.hide();
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
            });
			
			
			
			     
			
			 module.controller('MissingPersonViewController', function ($scope, $http) {
                
                try {
                    var page = myNavigator.getCurrentPage();
                    var id = page.options.id; // Will return "value1"
					
					$scope.regnumber = {
					missingRegNum: id
					
					};
					 
					var regpera = JSON.stringify($scope.regnumber);
					
					
					
                     $http({
                        method: 'POST',
                        url: appurl+'/missingPersonDetails',
                        data: regpera,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					//	alert(JSON.stringify(serverResponse));
                        $scope.missingperson = serverResponse.missingPersonResponseBean;
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
            });
			    
				module.controller('DeathBodyController', function ($scope, $http) {
                
                
                 $scope.open = function (id) {
					
                    myNavigator.pushPage('deathbodyview.html', {
                        animation: 'slide',
                        id: id
                    });
                }
				
				
				    
				$scope.opensearch = function (cond) {
					
					if(cond=="showdiv")
					{
						
					
					 document.getElementById("mseachform").style.display = "block"; 
					 document.getElementById("hdiv").style.visibility = "visible"; 
					 document.getElementById("sdiv").style.visibility = "hidden"; 
					}
					else
					{
					 document.getElementById("mseachform").style.display = "none"; 
					 document.getElementById("hdiv").style.visibility = "hidden"; 
					 document.getElementById("sdiv").style.visibility = "visible"; 
					}
                    
                }
				
					$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
						
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					// call gender webservice
					$scope.sendparametegen ={				
					langCd:99
					};
					var peragen = JSON.stringify($scope.sendparametegen);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterGenderType',
                        data: peragen,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.genders = serverResponse.masterResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
				
				$scope.searchmissing = function (form) {
					var valid=0;
				//	alert('hi');
					if($scope.datefrom==undefined)
					{
						
						 valid+=1;
						
					
					}
					
					
					if($scope.dateo==undefined)
					{
						
						
						 valid+=1;
					
					}
					
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.thanadist==undefined)
					{
					$scope.thanadist=0;
					
					}
					if($scope.age==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.gender==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.regno==undefined)
					{
					
					 valid+=1;
					
					}
					
				//	alert(valid);
					if(valid==6)
					{
						alert("you must fill in at least one field");
						return false;
					}
					
					if($scope[form].$valid) 
					{
						
						
						
						if($scope.datefrom==undefined)
					{
						datfrom='1900-01-01 00:00:00';
						
						
					
					}
					else
					{
						
						var datfrom = getFormattedDate($scope.datefrom);
						 datfrom = datfrom + ' 00:00:00';

						
						
					}
					
					if($scope.dateo==undefined)
					{
					//	alert($scope.dateo);
						datto='9999-01-01 00:00:00';
						
					
					}
					else
					{
						
						
						var datto = getFormattedDate($scope.dateo);
						datto = datto + ' 00:00:00';
					}
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					$scope.dist=0;
					
					
					}
					
					if($scope.thanadist==undefined)
					{
					$scope.thanadist=0;
					
					}
					
					if($scope.gender==undefined)
					{
					$scope.gender=0;
					 
					
					}
					
					if($scope.regno==undefined)
					{
					$scope.regno='';
					
					
					}
					if($scope.age==undefined)
					{
					$scope.age=0;
					
					
					}
						modal.show();
					//alert($scope.datefrom);
					//alert($scope.dateo);
					
					
					
						
					//	alert(datfrom);
					//	alert(datto);
					//	var date = new Date($scope.dob);
//var  dob=date.getFullYear()  + '-'+ (date.getMonth() + 1) + '-'+ date.getDate() +' 00:00:00.000';
//alert(datfor);
					$scope.searchpera = {				
					policeStationCd: $scope.thanadist,
					districtCd: $scope.dist,
					gender: $scope.gender,
					age:$scope.age,
					fromDate: datfrom,
					toDate: datto,
					placeBurnmark:0,
					placeBlackmark :0,
					placeLeucoderma :0,
					placeMole :0,
					placeScar :0,
					placeTattoo :0,
					firRegNum: $scope.regno
					
					};
					 
					var parameter = JSON.stringify($scope.searchpera);
               //  alert(parameter);
                    $http({
                        method: 'POST',
                        url: appurl+'/unIdentifiedDeadBody',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                  //      alert(JSON.stringify(serverResponse));
                        modal.hide();
				//	  alert(JSON.stringify(serverResponse));
						if(serverResponse==null)
						{
						alert("Data not found");
						}
						else
						{
							$scope.missingpersons = serverResponse.uidbResponseBean;
							$scope.$apply();
							
							
							document.getElementById("mseachform").style.display = "none"; 
							document.getElementById("hdiv").style.visibility = "hidden"; 
							document.getElementById("sdiv").style.visibility = "visible"; 	
						
						}
							 
					//	  modal.hide();
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
						  modal.hide();
                    });
					
					}
					else
					{
					$scope.showMsgs = true;
					}
				 }
				 
				 $scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                     //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
				  
            
            });
				
				
			 
				
				
				
				 module.controller('DeathBodyViewController', function ($scope, $http) {
                
                try {
                    var page = myNavigator.getCurrentPage();
                    var id = page.options.id; // Will return "value1"
					
					$scope.regnumber = {
					dbInquestNum: id,
					langCd:6
					
					};
					 
					var regpera = JSON.stringify($scope.regnumber);
					
					
					
                     $http({
                        method: 'POST',
                        url: appurl+'/unIdentifiedDeadBodyDetails',
                        data: regpera,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					  // alert(JSON.stringify(serverResponse));
                        $scope.missingperson = serverResponse.uidbResponseBeanDetails;
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
            });
			
			   module.controller('ComplaintController', function ($scope, $http) { 
						 $scope.mydelta = [{}];
						 
						  
						 
					try {
                    $http({
                        method: 'GET',
                        url: 'http://localhost/appcityzen/index.php/site/doctypes',
                        // data: dataToPost,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                        $scope.items = serverResponse;
                        $scope.$apply();
                        modal.hide();
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }											  
																  
				 $scope.choices = [{dist:'',ino:'',mobile1:'',url:''}];
				 
				  
				  $scope.addNewChoice = function() {
					var newItemNo = $scope.choices.length+1;
					$scope.choices.push({'id':'choice'+newItemNo});
				  };
					
				  $scope.removeChoice = function() {
					var lastItem = $scope.choices.length-1;
					$scope.choices.splice(lastItem);
				  };
				  
				  $scope.getFileDetails = function (e) {

            $scope.files = [];
            $scope.$apply(function () {

                // STORE THE FILE OBJECT IN AN ARRAY.
                for (var i = 0; i < e.files.length; i++) {
                    $scope.files.push(e.files[i])
                }

            });
        };

				  
                 $scope.complaint = function () { 
				  
					$scope.mydelta.push({"choice":$scope.choices});
                    $scope.mydelta.push({"formid":$scope.user});
                    modal.show();
                    $http({
                        method: 'POST',
                        url: 'http://localhost/appcityzen/index.php/site/complaint',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},			
				        data: $scope.mydelta
                    }).success(function (serverResponse, status, headers, config) {
					  
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
					 
				 
				
				    
					
					
                }
				
				
				
				
            });
			   
			   
			      module.controller('MissingPersonSearch', function ($scope, $http) {
                
                 $scope.open = function (id) {
                    myNavigator.pushPage('missingpersonview.html', {
                        animation: 'slide',
                        id: id
                    });
                }
				
				
					$scope.opensearch = function (cond) {
					
					if(cond=="showdiv")
					{
						
					
					 document.getElementById("mseachform").style.display = "block"; 
					 document.getElementById("hdiv").style.visibility = "visible"; 
					 document.getElementById("sdiv").style.visibility = "hidden"; 
					}
					else
					{
					 document.getElementById("mseachform").style.display = "none"; 
					 document.getElementById("hdiv").style.visibility = "hidden"; 
					 document.getElementById("sdiv").style.visibility = "visible"; 
					}
                    
                }
				
					$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					// call gender webservice
					$scope.sendparametegen ={				
					langCd:99
					};
					var peragen = JSON.stringify($scope.sendparametegen);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterGenderType',
                        data: peragen,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.genders = serverResponse.masterResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
				
				$scope.searchmissing = function (form) {
					function getFormattedDate(date)
						{
						var year = date.getFullYear();
						var month = (1 + date.getMonth()).toString();
						month = month.length > 1 ? month : '0' + month;
						var day = date.getDate().toString();
						day = day.length > 1 ? day : '0' + day;
						return year + '-' + month + '-' + day;
						}
					
					var valid=0;
					if($scope.datefrom==undefined)
					{
						
						 valid+=1;
						
					
					}
					
					
					if($scope.dateo==undefined)
					{
						
						
						 valid+=1;
					
					}
					
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.thanadist==undefined)
					{
					$scope.thanadist=0;
					
					}
					if($scope.age==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.gender==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.regno==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.name==undefined)
					{
					
					 valid+=1;
					
					}
					
				//	alert(valid);
					if(valid==7)
					{
						alert("you must fill in at least one field");
						return false;
					}
					 
					if($scope[form].$valid) 
					{
						if($scope.datefrom==undefined)
					{
						datfrom='1900-01-01 00:00:00';
						
						
					
					}
					else
					{
						
						var datfrom = getFormattedDate($scope.datefrom);
						 datfrom = datfrom + ' 00:00:00';

						
						
					}
					
					if($scope.dateo==undefined)
					{
					//	alert($scope.dateo);
						datto='9999-01-01 00:00:00';
						
					
					}
					else
					{
						
						
						var datto = getFormattedDate($scope.dateo);
						datto = datto + ' 00:00:00';
					}
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					$scope.dist=0;
					
					
					}
					
					if($scope.thanadist==undefined)
					{
					$scope.thanadist=0;
					
					}
					
					if($scope.gender==undefined)
					{
					$scope.gender=0;
					 
					
					}
					
					if($scope.regno==undefined)
					{
					$scope.regno='';
					
					
					}
					if($scope.age==undefined)
					{
					$scope.age=0;
					
					
					}
						if($scope.name==undefined)
					{
					$scope.name="";
					
					
					}
					
				 modal.show();
					//alert($scope.datefrom);
					//alert($scope.dateo);
					
					
					
				
						
					//	alert(datfrom);
					//	alert(datto);
					//	var date = new Date($scope.dob);
//var  dob=date.getFullYear()  + '-'+ (date.getMonth() + 1) + '-'+ date.getDate() +' 00:00:00.000';
//alert(datfor);
					$scope.searchpera = {				
					policeStationCd: $scope.thanadist,
					districtCd: $scope.dist,
					gender: $scope.gender,
					age:$scope.age,
					category:0,
					fromDate: datfrom,
					toDate: datto,
					placeBurnmark:0,
					placeBlackmark :0,
					placeLeucoderma :0,
					placeMole :0,
					placeScar :0,
					placeTattoo :0,
					foundStatus:0,
					firRegNum:$scope.regno,
					personName:$scope.name
					
					};
					
					var parameter = JSON.stringify($scope.searchpera);
               //  alert(parameter);
                    $http({
                        method: 'POST',
                        url: appurl+'/missingPersonList',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					
					 
                      modal.hide();
				//	  alert(JSON.stringify(serverResponse));
						if(serverResponse==null)
						{
						alert("Data not found");
						}
						else
						{
							$scope.missingpersons = serverResponse.missingPersonResponseBean;
							$scope.$apply();
							
							
							document.getElementById("mseachform").style.display = "none"; 
							document.getElementById("hdiv").style.visibility = "hidden"; 
							document.getElementById("sdiv").style.visibility = "visible"; 	
						
						}
				   
                         
							 
					//	  modal.hide();
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
						 modal.hide();
                    });
					
				}
					
				else
				{
				$scope.showMsgs = true;
				}
			 }
				 
				 $scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                     //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
				  
            
				
            });
				   
				   
		/*		   module.directive('fileModel', ['$parse', function ($parse) {return {
           restrict: 'A',
           link: function(scope, element, attrs) {
              element.bind('change', function(){
              $parse(attrs.fileModel).assign(scope,element[0].files)
                 scope.$apply();
              });
           }
        };
     }]).controller('myCtrl', ['$scope', '$http', function($scope,$http){ 
	 
	 
	 	try {
                    $http({
                        method: 'GET',
                        url: 'http://localhost/rest/doctypes',
                        // data: dataToPost,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                        $scope.items = serverResponse;
                        $scope.$apply();
                        modal.hide();
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
	 
	    $scope.choices = [{}];
				  $scope.changearticle = function () {
					   var articledata = "";
					    var artileid  = "";
					   
					   var len =   $scope.choices.length;
					    artileid = $scope.choices[len-1].dist;					   
					    
					   $http({
                        method: 'GET',
                        url: 'http://localhost/rest/DoctypeById?id='+artileid,
                        // data: dataToPost,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                        articledata = serverResponse.details;
						$scope.choices[len-1].title =articledata ;
					//	alert(articledata);
						 
                        $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                       // $scope.choices[len-1].title = "IMEI/ESN No";
                    });
					  
					  
			          
					   
					  
					   
					    
					   }
				  
				  $scope.addNewChoice = function() {
					var newItemNo = $scope.choices.length+1;
					$scope.choices.push({'id':'choice'+newItemNo});
				  };
					
				  $scope.removeChoice = function() {
					var lastItem = $scope.choices.length-1;
					$scope.choices.splice(lastItem);
				  };
	   
	  $scope.user = {
       
        name: ""
    };
	 var useridval = window.localStorage["userid"];
	$scope.userval = {
       
        id: useridval
    };
	  
	   $scope.files = [];
	    $scope.LoadFileData = function(files) {	
		alert('hi');
          //$scope.files.push(files[0]);
		  			 var fileToLoad = files[0];
					 
					 var size = parseFloat(files[0].size / 1024/1024).toFixed(2);
					// alert(size);
					if(size<=2)
			{
        var fileReader = new FileReader();

        fileReader.onload = function(fileLoadedEvent) {
            var srcData = fileLoadedEvent.target.result; // <--- data: base64

            var newImage = document.createElement('img');
            newImage.src = srcData;
			alert(newImage.src);
		//	 $scope.files.push(newImage.src);	
			//  alert(JSON.stringify($scope.files));
				$scope.imagedata.push({
				imagename: newImage.src
				});
			//	alert(JSON.stringify($scope.items));

       //    document.getElementById("imgTest").innerHTML = newImage.outerHTML;
        //    alert("Converted Base64 version is "+document.getElementById("imgTest").innerHTML);
        //    console.log("Converted Base64 version is "+document.getElementById("imgTest").innerHTML);
        }
        fileReader.readAsDataURL(fileToLoad);
		}
			 
     //      $scope.files.push(newImage.src);	
		//   alert(JSON.stringify($scope.files));

		  
		  
		
		 
    };

       $scope.uploadFile=function(form){
		    if ($scope[form].$valid) {	
		   
		    
		  $http({
            url: "http://localhost/rest/complaint",
            method: "POST",
            headers: { "Content-Type": undefined },
            transformRequest: function(data) {
                var formData = new FormData();
                 formData.append("user", angular.toJson($scope.user));
				  formData.append("useridval", angular.toJson($scope.userval));
				 formData.append("choice", angular.toJson($scope.choices));
                for (var i = 0; i < data.files.length; i++) {
                    formData.append("files[" + i + "]", data.files[i]);
                }
               return formData;

            },
            data: {files:$scope.files,user:$scope.user,choice:$scope.choices,useridval:$scope.userval}
        })
			.success(function(response) {   
			  
			   cid= response.id;
               $scope.$apply();
			    myNavigator.pushPage('acknowledge.html', {
                        animation: 'slide',
						id:cid
						
                    });
			  
			  
			  });
		  
			}
			
			else
			{
				 $scope.showMsgs = true;
			}


       }
     }]);*/
				   
			
			 
			 
			 	   
		   module.directive('fileModel', ['$parse', function ($parse) {return {
           restrict: 'A',
           link: function(scope, element, attrs) {
              element.bind('change', function(){
              $parse(attrs.fileModel).assign(scope,element[0].files)
                 scope.$apply();
              });
           }
        };
     }]).controller('Incident', ['$scope', '$http', function($scope,$http){
		 
		  $scope.files = [];
	    $scope.LoadFileDataNew = function(files) {			 
        
		
		for (var i = 0; i < files.length; i++) {
			
			 
           $scope.files.push(files[i]);	
		   
		}
    };
	
	
	$scope.uploadFileincident=function(form){
		    if ($scope[form].$valid) {	
		   
		 var useridval = window.localStorage["userid"];
		$scope.userval = {
		   
			id: useridval
		};
		  $http({
            url: "http://localhost/rest/addincident",
            method: "POST",
            headers: { "Content-Type": undefined },
            transformRequest: function(data) {
                var formData = new FormData();                
				  formData.append("user", angular.toJson($scope.user));
				  formData.append("useridval", angular.toJson($scope.userval));
                for (var i = 0; i < data.files.length; i++) {
                    formData.append("files[" + i + "]", data.files[i]);
                }
               return formData;

            },
            data: {files:$scope.files,user:$scope.user,useridval:$scope.userval}
        })
			.success(function(response) {   
			 
			   alert('Send successfully');
			 
			  window.location.reload(true);
			  
			  });
		  
			}
			
			else
			{
				 $scope.showMsgs = true;
			}


       }
	
	
	
		 
		 }]);
		   
		     module.controller('addItemController', function ($scope) {
			
			
			  try {
				  
				 
					
				/*	var doc = new jsPDF();
					var img = new Image();

    
  //  img.src = 'images/banner1.jpg';
var imgData = 'data:image/jpeg;base64,';
 //doc.addImage(img, 'JPEG', 5, 5, 140, 30);
 doc.addImage(imgData, 'JPEG', 15, 40, 180, 160);
doc.text(20, 20, 'HELLO!');
 
doc.setFont("courier");
doc.setFontType("normal");
doc.text(20, 30, 'This is a PDF document generated using JSPDF.');
doc.text(20, 50, 'YES, Inside of PhoneGap!');
 
var pdfOutput = doc.output();
console.log( pdfOutput );
 
//NEXT SAVE IT TO THE DEVICE'S LOCAL FILE SYSTEM
console.log("file system...");
window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fileSystem) {
 
  // alert(fileSystem.name);
 //  alert(fileSystem.root.name);
 //  alert(fileSystem.root.fullPath);
 
   fileSystem.root.getFile("test.pdf", {create: true}, function(entry) {
      var fileEntry = entry;
	  
	   var cdvfileURL = entry.toInternalURL();
	 //  alert(cdvfileURL);
	 
 	//   alert (JSON.stringify(fileEntry)); 
	//   alert(fileEntry.nativeURL);
 
      entry.createWriter(function(writer) {
         writer.onwrite = function(evt) {
         console.log("write success");
      };
 
      console.log("writing to file");
         writer.write( pdfOutput );
			var filePDF = 'tes.pdf';
			cordova.plugins.fileOpener2.open(
			fileEntry.nativeURL, // path file:///data/data/<app-id>/files/tes.pdf
			'application/pdf', 
			{ 
			error : function(e) { 
				alert('Error status: ' + e.status + ' - Error message: ' + e.message);
				},
			success : function () {
				//	alert('file opened successfully');                
				 }
			  }
			);
		}, function(error) {
         console.log(error);
      });
 
   }, function(error){
      console.log(error);
   });
},
function(event){
 console.log( evt.target.error.code );
});*/
					
                 /* var dd=  { content: 'this is  vikas saxena' };
				  

var folder = "pdfmakernew";
var appDirectory;
    window.requestFileSystem(LocalFileSystem.PERSISTENT,0, function(fileSys){
        fileSys.root.getDirectory(folder, {create:true, exclusive: false}, function(directory){
            appDirectory = directory;
			alert(appDirectory.fullPath);
			
			
            console.log("App directory initialized.");
    }, fail);   
		
		
 }, fail);

function fail(error) {
     console.log("App directory Error: "+error.code);
}

pdfMake.createPdf(dd).getBuffer(function (buffer) {
		alert("PDF Download Successfully");
		
        var utf8 = new Uint8Array(buffer); // Convert to UTF-8...                
        binaryArray = utf8.buffer; // Convert to Binary...
        save(binaryArray,"Test.pdf")
});

function save(data,savefile){
    var html = savefile;
	
    appDirectory.getFile(html, {create:true, exclusive: false}, function(fileEntry){
        fileEntry.createWriter(win,fail);
    }, fail);

    function win(writer) {
        writer.onwriteend = function(evt) {
            if (writer.length === 0) {
                writer.write(data);
            } else { }
        };
        writer.truncate(0);
		 var win = window.open( appDirectory.fullPath+'Test.pdf', '_blank' );
     	win.focus();		
        console.log("Write success");
        alert("Saving is successful.")
    };

    function fail(error) {
        console.log("Writer Error: "+error.code);
    }
}*/


var htmldata ='<div class="container">';
htmldata +='<div class="page-header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class="img-responsive center-block" src="images/banner1.jpg" width="391" height="112" /></div><div class="row text-center"><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;INFORMATION REPORT </h3><br><h4>IN RESPECT OF ARTICLE/DOCUMENT LOST IN ________________<br><br>Complaint ID: MPPOLICE/16/03/4567 </h4>    </div>    <hr>';
 htmldata +='   <div class="row" style="background-color:;">';
  htmldata +='  	<div class="col-sm-4">Date : 11/03/2016</div>';
  htmldata +='      <div class="col-sm-4">Higher Office :</div>';
  htmldata +='      <div class="col-sm-4">Police Station : MP Nagar</div>';
  htmldata +='   </div>';
 htmldata +='    <hr>';
 htmldata +='    <div class="table-responsive">';
  htmldata +='   		<table class="table">';
   htmldata +='      	<tr style="font-weight:bold;">';
   htmldata +='          	<td>1</td><td>Personal Details :</td><td></td><td></td>';
   htmldata +='          </tr>';
  htmldata +='           <tr>';
  htmldata +='           	<td></td><td>Name of Person:</td><td>Mr. Rajesh Verma</td><td></td>';
    htmldata +='         </tr>';
     htmldata +='         <tr><td></td><td>Mobile No:</td><td>+91-9977144332</td><td></td></tr>';
    htmldata +='         <tr>';
    htmldata +='         	<td></td><td>Address:</td><td></td><td></td>';
    htmldata +='         </tr>';

    htmldata +='         <tr style="font-weight:bold;"><td>2</td><td>Complaint Details :</td><td></td><td></td></tr><tr>';
    htmldata +='         	<td></td><td>Item Number:</td><td>1</td><td></td>';
   htmldata +='          </tr>';
   htmldata +='           <tr>';
    htmldata +='         	<td></td><td>Item Name:  </td><td>Sim Card Lost</td><td></td>';
   htmldata +='          </tr>';
   htmldata +='          <tr>';
   htmldata +='          	<td></td><td>Mobile Number: </td><td>+91-9981232426</td><td></td>';
           htmldata +='  </tr>';
            htmldata +=' <tr>';
            htmldata +=' 	<td></td><td>Place of Missing:</td><td>TT Nagar Bhopal Near HDFC Bank</td><td></td>';
            htmldata +=' </tr>';
            
		htmldata +=' 	<tr style="font-weight:bold;">';
       htmldata +='      <td>3</td><td>Occurrence Details :</td><td></td><td></td>';
      htmldata +='       </tr>';
     htmldata +='        <tr>';
     htmldata +='        	<td></td><td>Date and time of report :</td><td>15/2/2016</td><td>Time: 3:20:00</td>';
     htmldata +='        </tr>';
     htmldata +='         <tr>';
     htmldata +='        	<td></td><td>Date and time of Lost :</td><td>14/2/2016</td><td>Time: 2:00:20</td>';
      htmldata +='       </tr>';
      htmldata +='       <tr style="font-weight:bold;">';
      htmldata +='       	<td>4</td><td>Any other Description :</td><td></td><td></td>';
      htmldata +='       </tr>          ';  
     htmldata +='    </table>    <hr>';
   htmldata +='  </div>';

 htmldata +='    <div class="row">';
 htmldata +='    	<h4>Note :</h4>';
htmldata +=' 		<ol>';
htmldata +='         	<li>This is digitally signed document.</li>';
htmldata +=' 			<li>For Verification Please Visit the Web portal  www.mppolice.gov.in/verify_items</li>';
htmldata +=' 			<li>Authority issuing duplicate SIM may verify the proof of identity.MP Police is not liable for any identification.</li>';
htmldata +='         </ol><br>';
htmldata +=' 		<h4>Disclaimer :</h4>';
htmldata +=' 		<ol>';
 htmldata +='        	<li>This is digitally signed document.</li>';
htmldata +=' 			<li>For Verification Please Visit the Web portal  www.mppolice.gov.in/verify_items</li>';
htmldata +=' 			<li>Authority issuing duplicate SIM may verify the proof of identity.MP Police is not liable for any identification.</li>';
htmldata +=' 		</ol>';
htmldata +='     </div><br><br>';
htmldata +=' </div>';
window.html2pdf.create(
            htmldata,
           // "~/Documents/test.pdf", // on iOS,
             "test.pdf" 
        );
                } catch (e) {
                    alert(e);
                }
            });
			 
			 
			 
			 module.controller('DownloadController', function ($scope, $http) {
            
                try {
                    var id = window.localStorage["userid"];
                    $http({
                        method: 'GET',
                        url: 'http://localhost/rest/complaintdata?id='+id,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                        $scope.pdfdatas = serverResponse;
                        $scope.$apply();
                        modal.hide();
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
				   $scope.downloadpadf = function (id) {
					     
					   	 			   			   
					     
					   $http({
                        method: 'GET',
                        url: 'http://localhost/rest/pdfdownload?id='+id
                        // data: dataToPost,
                        
                    }).success(function (serverResponse, status, headers, config) {
						
						 var pdfname = serverResponse.id;
                         window.open(encodeURI('http://localhost/pdfpoliceapp/'+pdfname+'test.pdf'), '_blank','location=yes');
                       
                    }).error(function (serverResponse, status, headers, config) {
                      
                    });
					  
					  
			          
					   
					  
					   
					    
					   }
					   
					     
				
            });			
			 
			 
			  module.controller('ChangePasswordController', function ($scope, $http) {
			     
				 menu.close();
			   
                $scope.ChangeP = function (form) {
				 if ($scope[form].$valid) {	
                  
				    
				    var uid = window.localStorage["userid"];
                    $http({
                        method: 'POST',
                        url: 'http://localhost/rest/ChangePassword',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},			
				         data: {opassword: $scope.opassword,password: $scope.password,password_c: $scope.password_c,userid:uid},
                    }).success(function (serverResponse, status, headers, config) {	
					    alert(serverResponse.msg);
						window.location.reload(true);
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure : " + serverResponse.msg);
                    });
				 }
				 else
				 {
				 	 $scope.showMsgs = true;
				 }
                }
            });
			  
			      module.controller('RegControllerJava', function ($scope, $http) {
			  		menu.close();
					
					
					  
					 $scope.checkuser = function () {
						
					 
						$scope.loginidval ={				
						loginId:$scope.loginid
						};
					//masterDistrictsNameArv
					var parameter_loginid = JSON.stringify($scope.loginidval);
				 
					
					
					 $http({
                        method: 'POST',
                        url: appurl+'/userAvailable',
                        data: parameter_loginid,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						//alert(JSON.stringify(serverResponse));
                         $scope.loginidStatus = serverResponse.userAvailableResponseBean;
						 
						 if($scope.loginidStatus.msg=="EXIST")
						 {
							 
							 alert("Login Id Already Exist");
							 $scope.loginid="";
							
						}
						
						
						 
					//	 $scope.loginid="";
						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure"+serverResponse);
                    });
					
				 }
					$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					//masterDistrictsNameArv
					var parameter_district = JSON.stringify($scope.sendparamete);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;
						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure"+serverResponse);
                    });
                }
				
				catch (e) {
                    alert(e);
                }
				
				$scope.sendparamete1 ={				
					langCd:99
					};
					
					var parameter_doctype = JSON.stringify($scope.sendparamete1);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterNationalDocType',
                        data: parameter_doctype,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	alert(JSON.stringify(serverResponse));
                         $scope.doctypes = serverResponse.masterResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
				catch (e) {
                    alert(e);
                }
				
				
				$scope.sendparamete2 ={				
					langCd:99
					};
					
					var parameter_squestions = JSON.stringify($scope.sendparamete2);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterSecurityQuestions',
                        data: parameter_squestions,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	alert(JSON.stringify(serverResponse));
                         $scope.questions = serverResponse.masterResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
				catch (e) {
                    alert(e);
                }
			
			// call gender webservice
					$scope.sendparametegen ={				
					langCd:99
					};
					var peragen = JSON.stringify($scope.sendparametegen);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterGenderType',
                        data: peragen,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.genders = serverResponse.masterResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
			
			
			
			
                $scope.register = function (form) {
				
				 
					
					
				 
                  
				//  window.location.href = url;
					 if ($scope[form].$valid) {	
				document.getElementById("regform").style.display = "none";	
				 document.getElementById("otpform").style.display = "block";
					  
				//		modal.show();
					
						
						function getFormattedDate(date) {
  var year = date.getFullYear();
  var month = (1 + date.getMonth()).toString();
  month = month.length > 1 ? month : '0' + month;
  var day = date.getDate().toString();
  day = day.length > 1 ? day : '0' + day;
  return year + '-' + month + '-' + day;
}
						
						var datfor = getFormattedDate($scope.dob);
						
						if($scope.mname==undefined)
						{
							$scope.mname="";
						
						}

						
					//	var date = new Date($scope.dob);
//var  dob=date.getFullYear()  + '-'+ (date.getMonth() + 1) + '-'+ date.getDate() +' 00:00:00.000';
//alert(datfor);
					$scope.registration = {				
					
					strLoginId: $scope.loginid,				
					strPassword: $scope.password,
					strFirstName: $scope.name,
					strMiddleName: $scope.mname,
					strLastName: $scope.lname,					
					strEmail: $scope.email,
					strAddressLine1: $scope.address,
					strMobile1: $scope.mobile,			
					strDateOfBirth: datfor,
					strNationalIdTypeCd: $scope.idtype,
					strNationalIdNumber: $scope.idnumber,
					strSecurityQuestionCd1: $scope.security,
					strSecurityAnswer1: $scope.answer,
					strDistrictCd: $scope.district,
					langCd: 99
					};
					
					
					
					
					$scope.otppera ={				
					langCd:99
					};
					var otpval = JSON.stringify($scope.otppera);
					
					 $http({
                        method: 'POST',
                        url: appurl+'/sendGetOtp',
                        data:otpval,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.valotp = serverResponse;	
						 	var sms="Dear "+$scope.name+" ,  Your OTP for Citizen App Registration is :"+$scope.valotp.otp+",Please use the password to complete the registration,please do not share this with anyone";
								var url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=48e1745ebcfcdc80bcc238ec2ce96ac&message="+sms+"&senderId=dddddd&routeId=1&mobileNos="+$scope.mobile+"&smsContentType=english"
								
									
									var xhttp = new XMLHttpRequest();
									xhttp.onreadystatechange = function() {
									if (xhttp.readyState == 4 && xhttp.status == 200) {
									
									}
									};
									xhttp.open("GET", url, true);
									xhttp.send();
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
					
					
					
			
                 /*   $http({
                        method: 'POST',
                        url: appurl+'/submitUserRegistration',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					
							
								  $scope.result = serverResponse.validateUserResponseBean;
								    $scope.$apply();
								  modal.hide();
								 
  							
							
							
							
							
							if($scope.result.userRegCount>0)
							{
								alert($scope.result.message);
							}
							
							else
							{
								
								var sms="Dear "+$scope.name+" , Thanks for registered with CITIZEN APP . Your Login Id is : "+$scope.loginid+" and your  Password is :-"+$scope.password+" .";
								var url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=48e1745ebcfcdc80bcc238ec2ce96ac&message="+sms+"&senderId=dddddd&routeId=1&mobileNos="+$scope.mobile+"&smsContentType=english"
								
									
									var xhttp = new XMLHttpRequest();
									xhttp.onreadystatechange = function() {
									if (xhttp.readyState == 4 && xhttp.status == 200) {
									
									}
									};
									xhttp.open("GET", url, true);
									xhttp.send();
									$scope.loginid="";
									$scope.password="";
									$scope.password_c="";
									$scope.name="";
									$scope.mname="";
									$scope.lname="";
									$scope.gender="";
									$scope.email="";
									$scope.district="";
									$scope.address="";
									$scope.mobile="";
									$scope.dob="";
									$scope.idtype="";
									$scope.idnumber="";
									$scope.security="";
									$scope.answer="";
								
									alert("Registration Successful.! Login credentials have been sent to the given mobile number");
									myNavigator.pushPage('login.html', {
								animation: 'slide'
								});
							}
							
							
					 
					   
							
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure : Connection Problem!!");
                    });*/
                } 
		else 
		{
               $scope.showMsgs = true;
       }
					
                }
				
				 $scope.loginotp = function (form) {
				 if ($scope[form].$valid) {               
				   
					
				   if($scope.valotp.otp==$scope.otp)
				   {
					   var parameter = JSON.stringify($scope.registration);
					
						 $http({
                        method: 'POST',
                        url: appurl+'/submitUserRegistration',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					
							
								  $scope.result = serverResponse.validateUserResponseBean;
								    $scope.$apply();
								  modal.hide();
								 
  							
							
							
							
							
							if($scope.result.userRegCount>0)
							{
								alert($scope.result.message);
							}
							
							else
							{
								
								var sms="Dear "+$scope.name+" , Thanks for registered with CITIZEN APP . Your Login Id is : "+$scope.loginid+" and your  Password is :-"+$scope.password+" .";
								var url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=48e1745ebcfcdc80bcc238ec2ce96ac&message="+sms+"&senderId=dddddd&routeId=1&mobileNos="+$scope.mobile+"&smsContentType=english"
								
									
									var xhttp = new XMLHttpRequest();
									xhttp.onreadystatechange = function() {
									if (xhttp.readyState == 4 && xhttp.status == 200) {
									
									}
									};
									xhttp.open("GET", url, true);
									xhttp.send();
									$scope.loginid="";
									$scope.password="";
									$scope.password_c="";
									$scope.name="";
									$scope.mname="";
									$scope.lname="";
									$scope.gender="";
									$scope.email="";
									$scope.district="";
									$scope.address="";
									$scope.mobile="";
									$scope.dob="";
									$scope.idtype="";
									$scope.idnumber="";
									$scope.security="";
									$scope.answer="";
									$scope.otp="";
									
									document.getElementById("regform").style.display = "block";	
									document.getElementById("otpform").style.display = "none";
								
									alert("Registration Successful.! Login credentials have been sent to the given mobile number");
									/*myNavigator.pushPage('login.html', {
								animation: 'slide'
								});*/
										window.location.reload(true);
							}
							
							
					 
					   
							
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure : Connection Problem!!");
                    });
					}
					else
					{
						alert("Invalid OTP");
					}
				   
                   
				 }
				 else
				 {
				 	 $scope.showMsgs = true;
				 }
                }
            });
			
			
				module.controller('myCtrl', function ($scope, $http) {
													  
													  
						
                		//var id= window.localStorage["userid"];
						
				try {
                    
                //    var id = $scope.st; // Will return "value1"
				var id = 	window.localStorage["userid"];
			//	alert(id);
                   $scope.userdeatils ={
					loginId:id
					};
					
					var userpera = JSON.stringify($scope.userdeatils);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/userProfileDisplay',
                        data: userpera,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                     //    alert(JSON.stringify(serverResponse));
						$scope.users = serverResponse.userProfileResponseBean;	
						
                        $scope.fullname = $scope.users.firstName;
						$scope.mobile = $scope.users.mobileNum;
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
             
			 
					$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
					
					 
				  
				  
				  
				  
				  
				//	alert(parameter_district);
					 try {
						 
						
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;	
						  $scope.districtsnew = serverResponse.masterResponseBean;	
						 
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("Check your connection");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					$scope.lostarticle ={				
					langCd:99
					};
					
					var larticle = JSON.stringify($scope.lostarticle);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getLostArticleCategory',
                        data: larticle,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.lostarticles = serverResponse.lostArticleResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("Check your connection");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					//article type electronics
					
					$scope.lostarticleelec ={				
					langCd:99
					};
					
					var larticleelec = JSON.stringify($scope.lostarticleelec);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getElectronicGoods',
                        data: larticleelec,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						//alert(JSON.stringify(serverResponse));
                         $scope.electronics = serverResponse.lostArticleSubTypeResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("Server Busy,Please try after some time... ");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
						//article type documents
					
					$scope.lostarticledoc ={				
					langCd:99
					};
					
					var larticledoc = JSON.stringify($scope.lostarticledoc);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getDocumentsType',
                        data: larticledoc,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					 //	alert(JSON.stringify(serverResponse));
                         $scope.documents = serverResponse.lostArticleSubTypeResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        //alert("Server Busy,Please try after some time... ");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					
					// call gender webservice
					$scope.sendparametegen ={				
					langCd:99
					};
					var peragen = JSON.stringify($scope.sendparametegen);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterGenderType',
                        data: peragen,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.genders = serverResponse.masterResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					
					// call country webservice
					$scope.sendparametecountry={				
					langCd:99
					};
					var country = JSON.stringify($scope.sendparametecountry);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterNationality',
                        data: country,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.countries = serverResponse.nationalityResponseBean;
						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					//call_relative
					$scope.relative={				
					langCd:99
					};
					var re = JSON.stringify($scope.relative);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getRelativesType',
                        data: re,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.relativedatas = serverResponse.relativesTypeResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
				$scope.articletype = function () { 
				
					if($scope.articlename==11)
					{
						document.getElementById("documentid").style.display = "block";
						document.getElementById("electronicid").style.display = "none";
					}
					else if($scope.articlename==13)
					{
						document.getElementById("electronicid").style.display = "block";
						document.getElementById("documentid").style.display = "none";
						
					
					}
				//	$scope.documentid  = true;
				 }	
					
				 $scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                     //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 
				 
				 	 $scope.thana1 = function () { 
				 
					$scope.sendparamete3 ={				
					langCd:99,
					districtCd:$scope.distaddress
					};
					
					var parameter3 = JSON.stringify($scope.sendparamete3);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter3,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                      //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatasnew = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 
				 
				 //state_webservice
				  $scope.statefunc = function () { 
				  
				  if($scope.country==80)
				  {
				 
					$scope.stateval ={				
					langCd:99
					
					};
				//	alert($scope.country);
					var parameter2 = JSON.stringify($scope.stateval);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterState',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                  //    alert(JSON.stringify(serverResponse));
                         $scope.states = serverResponse.stateResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure" + serverResponse);
                    });
					
				  }
				 }
				 
				 
				 $scope.lostsend = function (form) {
					 if ($scope[form].$valid) 
					 {	
					// alert($scope.thanadist);
					//  alert(JSON.stringify($scope.thanadatas));
				//	 modal.show();
				
				
				
						function getstate(sid)
				{
					
					for(i=0;i<= $scope.states.length;i++)
						{
						
							if(sid==$scope.states[i].stateCd)
							{
							
							var stname=$scope.states[i].stateList;
							
							
							return stname;
							
							}
						}
				
				
				}

			var statename	=	getstate($scope.state);
				
					function getdistrict(did)
				{
					
					for(i=0;i<= $scope.districts.length;i++)
						{
						
							if(did==$scope.districts[i].districtCode)
							{
							
							var distname=$scope.districts[i].districtName;
							
							
							return distname;
							
							}
						}
				
				
				}

			var dname=	getdistrict($scope.dist);
			
				function getthana(tid)
				{
						for(i=0;i<= $scope.thanadatas.length;i++)
						{
						
							if(tid==$scope.thanadatas[i].policeStationCd)
							{
							
							var thananame=$scope.thanadatas[i].policeStationName;
							
							
							
							return thananame;
							
							}
						}
				
				
				}

		var tname=	getthana($scope.thanadist);
		
		var disadd=	getdistrict($scope.distaddress);
		var psadd=	getthana($scope.psaddress);
		
		
					var uid= window.localStorage["userid"];
					// alert(uid);
				//	 alert($scope.lttime);
					function getFormattedDate(date)
					{
					var year = date.getFullYear();
					var month = (1 + date.getMonth()).toString();
					month = month.length > 1 ? month : '0' + month;
					var day = date.getDate().toString();
					day = day.length > 1 ? day : '0' + day;
					return year + '-' + month + '-' + day;
					}
					function format_time(date_obj) {
					// formats a javascript Date object into a 12h AM/PM time string
					var hour = date_obj.getHours();
					var minute = date_obj.getMinutes();
					var second  =  '00';
					var amPM = (hour > 11) ? "pm" : "am";
					  if(hour <10) {
					hour = "0"+hour;
					}
					if(minute < 10) {
					minute = "0" + minute;
					}
					return hour + ":" + minute + ":"+second;
					}
					
					var d = format_time($scope.lttime);

					
						var datfrom = getFormattedDate($scope.ltdate);
						
					 	datfrom = datfrom + ' '+d;
						// alert(datfrom);
						
						var currentTime = new Date();
						
						 


   							function getFormattedDatenew(date)
					{
					var year = date.getFullYear();
					var month = (1 + date.getMonth()).toString();
					month = month.length > 1 ? month : '0' + month;
					var day = date.getDate().toString();
					day = day.length > 1 ? day : '0' + day;
					
					var hour = date.getHours();
					var minute = date.getMinutes();
					var second  =  date.getSeconds();
					var amPM = (hour > 11) ? "pm" : "am";
					if(hour > 12) {
					hour -= 12;
					} else if(hour == 0) {
					hour = "12";
					}
					 else if(hour <10) {
					hour = "0"+hour;
					}
					if(minute < 10) {
					minute = "0" + minute;
					}
					return year + '-' + month + '-' + day+' '+hour+':'+minute+':'+second;
					}
					
					function IndiaTime(D){
					D= D || new Date();
					D.setUTCMinutes(D.getUTCMinutes()+330);
					
					var A= [D.getUTCHours(), D.getUTCMinutes(), D.getUTCSeconds()];
					if(A[1]<10) A[1]= '0'+A[1];
					if(A[2]<10) A[2]= '0'+A[2];
					return A.join(':');
					}

 						var ctime = IndiaTime();
						
 					   var year = currentTime.getFullYear();
					   
					   
					   
					  var cdate  = getFormattedDatenew(currentTime);
					   var cdate  = getFormattedDate(currentTime)+ ' ' +ctime;
					   
					//   alert(cdate);
					   
					//   var cdate  = '2016-05-24 18:10:25';
					   
					   
					   
					 // cdate = cdate + ' 00:00:00';

                        //      alert(cdate);
						
				
				if($scope.imi==undefined)
				{
				$scope.imi="";
				
				}
				if($scope.quantity==undefined)
				{
				$scope.quantity="";
				
				}
				if($scope.ecost==undefined)
				{
				$scope.ecost="";
				
				}
				
				
				
				if($scope.isdn==undefined)
				{
				$scope.isdn="";
				
				}
				if($scope.dociden==undefined)
				{
				$scope.dociden="";
				
				}
				

					
					var mnum='+91'+$scope.mobile;
					
					var extradata='';

var r1=$scope.relative;

var r2=$scope.relativename;
//alert(r1+r2);
 
var xml_string ='<ROOT><COMPLAINANTPERSONINFO PERSONSN="1" PSCD="'+$scope.thanadist+'" PERSONCODE="0" LANGCD="6"';
xml_string +=' PERSONTYPECD="0" STATECD="21" DISTRICTCD="'+$scope.dist+'" ';
xml_string +='PSID="0" REGYEAR="'+year+'" FIRSTNAME="'+$scope.fullname+'" LASTNAME="'+$scope.users.lastName+'"';
xml_string +=' RELATIONTYPECD="'+r1+'" RELATIVENAME="'+r2+'" ';
xml_string +='AGE="0" YOB="0" SEX="0" MOBILE1="'+mnum+'" MOBILE2="0" ';
xml_string +='NATIONALITYCD="0" RELIGIONCD="0" CATEGORYCD="0" ';
xml_string +='CASTETRIBECD="0" EDUQUALCD="0" INCOMEGROUPCD="0" ';
xml_string +='OCCUPATIONCD="0"  GENDERCD="'+$scope.gender+'" NATIONALIDTYPECD="0" ';
xml_string +='AGEFROMYRS="0" AGETOYRS="0" HEIGHTFROMCM="0" HEIGHTTOCM="0" ';
xml_string +='WEIGHTKG="0" BUILDTYPE="0" BUILDSUBTYPE="0" COMPLEXIONTYPE="0" ';
xml_string +='COMPLEXIONSUBTYPE="0" FACETYPE="0" CHEEKTYPE="0" CHINTYPE="0" ';
xml_string +='MOUSTACHESTYPE="0" FOREHEADTYPE="0" BEARDTYPE="0" TEETHTYPE="0" ';
xml_string +='NOSETYPE="0" LIPSTYPE="0" ISPOXPITTED="0" VOICE="0" HAIRTYPE="0" ';
xml_string +='ISUSINGWIG="0" HAIRSTRAIGHTNESS="0" HAIRCUT="0" HAIRSTYLE="0" ';
xml_string +='HAIRCOLOR="0" HAIRLENGTH="0" HAIRDYE="0" EYETYPE="0" EYECOLOR="0" ';
xml_string +='EYEBLIND="0" EYEUSINGSPECS="0" EYESPECSTYPE="0" EYEBROWTHICKNESS="0" ';
xml_string +='EYEBROWSHAPE="0" EYEBLINKING="0" EYESQUINT="0" HABITS="0" ';
xml_string +='DRESSHABITS="0" EARSMISSING="0" EARSDEFORMED="0" DEAFDUMB="0" ';
xml_string +='ARMSMISSING="0" FINGEREXTRA="0" FINGERMISSING="0" ';
xml_string +='HUNCHBACK="0" LEGSMISSING="0" BOWLEG="0" LIMPING="0" ';
xml_string +='KNOCKKNEE="0" TOEEXTRA="0" TOEMISSING="0" EARLOBES="0" ';
xml_string +='ISGOITRE="0" LANGDIALECTCD="0" DRESSOUTERTOPCD="0" ';
xml_string +='DRESSOUTERBOTCD="0" DRESSINNERTOPCD="0" DRESSINNERBOTCD="0" ';
xml_string +='DRESSACCESSRYTOPCD="0" DRESSACCESSORYBOTCD="0" ';
xml_string +='DRESSFOOTWEARCD="0" DRESSUPPERCOLORCD="0" ';
xml_string +='RECORDSTATUS="0" RECORDCREATEDON="'+cdate+'" ';
xml_string +='RECORDCREATEDBY="'+uid+'"   RECORDUPDATEDFROM="0" ';
xml_string +='ORIGINALRECORD="1" MONTHS="0" />';
xml_string +='</ROOT>';

 //var xml_string_new = xml_string.replace("#", "'");
 
 //alert(xml_string_new);
 
 
 
 
 //var x= xml_string_new.replace("$", "'");

//alert(x);
 //xml_string = xml_string.replace("$", "'");
//present address

var xml_string1 ='<ROOT><COMPLAINANTADDRESS PERSONSN="1" ';
xml_string1 +='ISADDRESSSAME="Y" ADDRESSCD="1" LANGCD="6" ';
xml_string1 +='PERSONCODE="1" ADDRTYPE="1" VILLAGE="'+$scope.city+'" ';
xml_string1 +='COUNTRYCD="'+$scope.country+'" STATECD="'+$scope.state+'" DISTRICTCD="'+$scope.distaddress+'" PSCODE="0" ';
xml_string1 +='PINCODE="0" RECORDSTATUS="67" RECORDCREATEDON="'+cdate+'" ';
xml_string1 +='RECORDCREATEDBY="'+uid+'"   RECORDUPDATEDFROM="0" ';
xml_string1 +='DUMMYCOLUMN1="0" DUMMYCOLUMN2="0" ORIGINALRECORD="1" />';
xml_string1 +='</ROOT>';

//var xml_string_new1 = xml_string1.replace("#", "'");
 
 //var y= xml_string_new1.replace("$", "'");

//xml_string1 = xml_string.replace("$", "'");

//permanent address
 var xml_string2 = '<ROOT><COMPLAINANTADDRESS  PERSONSN="1" ISADDRESSSAME="Y" ';
xml_string2 +=' ADDRESSCD="1"  LANGCD="6" ';
xml_string2 +=' PERSONCODE="1"  ADDRTYPE="2"  VILLAGE="'+$scope.city+'" ';
xml_string2 +=' COUNTRYCD="'+$scope.country+'"  STATECD="'+$scope.state+'"  DISTRICTCD="'+$scope.distaddress+'"  PSCODE="0"  PINCODE="0" ';
xml_string2 +=' RECORDSTATUS="67" RECORDCREATEDON="'+cdate+'" ';
xml_string2 +=' RECORDCREATEDBY="'+uid+'"   RECORDUPDATEDFROM="0" ';
xml_string2 +=' DUMMYCOLUMN1="0" DUMMYCOLUMN2="0" ORIGINALRECORD="1" />';
xml_string2 +=' </ROOT>';

 //var xml_string2 = xml_string2.replace("#", "'");
 
 
//var xml_string_new2 = xml_string2.replace("#", "'");
 
// var z= xml_string_new2.replace("$", "'");
// xml_string2 = xml_string2.replace("$", "'");
if($scope.articlename==13)
{
var xml_string3 ='<ROOT>  <PROPERTY PROPERTYSN="1" PSCD="'+$scope.psaddress+'" ';
xml_string3 +='PROPERTYCD="'+$scope.articlename+'"  LANGCD="6"  PROPREGNUM="0"  TYPECD="0" ';
xml_string3 +='QUANTITY="'+$scope.quantity+'"  MAKE="'+$scope.manf+'"   VALUELOST="'+$scope.ecost+'" ';
xml_string3 +='VALUERECOVERED="0"  RECORDSTATUS="0"  RECORDCREATEDON="'+cdate+'" ';
xml_string3 +='RECORDCREATEDBY="'+uid+'"   RECORDUPDATEDFROM="0" ';
xml_string3 +='DUMMYCOLUMN1="0"  DUMMYCOLUMN2="0"  ORIGINALRECORD="1"  SUBTYPECD="'+$scope.electronic+'" />';
xml_string3 +='</ROOT>';

 //xml_string3= xml_string3.replace("#", "'");


//var xml_string_new3 = xml_string3.replace("#", "'");
 
//var z1= xml_string_new3.replace("$", "'");
 //xml_string3= xml_string3.replace("$", "'");

var xml_string4 ='<ROOT><XMLIDDETAIL  SRNO="0"  LANGCD="6" ';
xml_string4 +='PROPREGNUM="0" IDTYPE="1" IDNO="'+$scope.imi+'" ';
xml_string4 +='RECORDSTATUS="0"    ORIGINALRECORD="1" ';
xml_string4 +='PROPSRNO="1" /> <XMLIDDETAIL SRNO="1" LANGCD="6" ';
xml_string4 +='PROPREGNUM="0" IDTYPE="1" IDNO="'+$scope.isdn+'" ';
xml_string4 +='RECORDSTATUS="0"    ORIGINALRECORD="1" ';
xml_string4 +='PROPSRNO="1" />';
xml_string4 +='</ROOT>';

 extradata +='<tr>';
extradata +='<td></td><td>Estimated Cost:</td><td>'+$scope.ecost+'</td><td></td>';
extradata +='</tr>';
extradata +='<tr>';
extradata +='<td></td><td>Quantity:</td><td>'+$scope.quantity+'</td><td></td>';
extradata +='</tr>';
extradata +='<tr>';
extradata +='<td></td><td>Make:</td><td>'+$scope.manf+'</td><td></td>';
extradata +='</tr>';


}
else if($scope.articlename==11)
{
	
	var xml_string3 ='<ROOT><PROPERTY PROPERTYSN="1" PROPERTYCD="'+$scope.articlename+'" PSCD="'+$scope.psaddress+'" ';
	xml_string3 +='LANGCD="6" PROPREGNUM="0" DOCTYPE="'+$scope.documentval+'" DOCUMENTNUM="'+$scope.dociden+'" ';
	xml_string3 +='VALUELOST="'+$scope.ecostdoc+'" VALUERECOVERED="0" RECORDSTATUS="0" ';
	xml_string3 +='RECORDCREATEDON="'+cdate+'" RECORDCREATEDBY="'+uid+'" ';
	xml_string3 +='ISSECURITYTHREAD="0" ORIGINALRECORD="1" SUBTYPECD="'+$scope.documentval+'" /> ';
	xml_string3 +='</ROOT>';
	
	
	var xml_string4='';
 extradata +='<tr>';
extradata +='<td></td><td>Estimated Cost:</td><td>'+$scope.ecostdoc+'</td><td></td>';
extradata +='</tr>';
extradata +='<tr>';
extradata +='<td></td><td>Document Identity:</td><td>'+$scope.dociden+'</td><td></td>';
extradata +='</tr>';
}
  //var xml_string4 = xml_string4.replace("#", "'");
// xml_string4 = xml_string4.replace("$", "'");

//var xml_string_new4 = xml_string4.replace("#", "'");
 
//var z2= xml_string_new4.replace("$", "'");

var xml_string5 ='<ROOT>';
xml_string5 +='</ROOT>';

//xml_string5 = xml_string5.replace("#", "'");

//var xml_string_new5 = xml_string5.replace("#", "'");
 
//var z3= xml_string_new5.replace("$", "'");
 //xml_string5 = xml_string5.replace("$", "'");

//var xml_string5 = xml_string5.replace("#", "'");

var itemname="";
if($scope.articlename==13)
{
	if($scope.electronic==470)
	{
		itemname="Mobile";
	}
}
else if($scope.articlename==11)
{
	 
	if($scope.documentval==332)
	{
		itemname="Bank Draft";
	}
	else if($scope.documentval==339)
	{
		itemname="Cheques";
	}
	else if($scope.documentval==341)
	{
		itemname="Credit/Debit/ATM Card";
	}
	else if($scope.documentval==344)
	{
		itemname="Educational Certificate";
	}
	else if($scope.documentval==375)
	{
		itemname="Ration Card";
	}
	else if($scope.documentval==376)
	{
		itemname="Registration Certificate";
	}
	else if($scope.documentval==386)
	{
		itemname="Voter Id Card";
	}
	else if($scope.documentval==862)
	{
		itemname="Driving Licence";
	}
}

else
{
	
} 
		
		
		 
		$scope.insertdata = {				
					langCd: '6',
					stateCd: '21',
					districtCd: $scope.dist,
					psCd:$scope.thanadist,
					regYear: year,
					lostPropertySrNo: '0',
					regDate:cdate,
					gdNum :'null',
					enqDate :cdate,
					gdEntryDate :cdate,
					propRegNum :'0',
					enquaryOffCd :'1',
					remark: 'null',
					recordCreatedBy:uid,					
					lostDate:cdate,
					anyDocumentUploaded: 'N',
					lostPlace: $scope.ltlocation,
					originalRecord:'1',
					recordCreatedOn: cdate,
					recordUpdatedOn:cdate,
					recordSyncOn:cdate,
					xmlPersonInfo :xml_string,
					xmlComplPersentAddress :xml_string1,
					xmlComplPermnantAddress :xml_string2,
					xmlProperty :xml_string3,
					propertyValue:$scope.articlename,
				    complainantPersonCd:'1',
				    complainantAddrCd:'1',
				    documentUploadedDesc:'',
				    dummyColumn1:'1',
				    dummyColumn2:'1',
				    xmlFileUploaded:'',
				    currenctDetails:'',
				    xmlElectricalGoodsDetails:xml_string4,
				    xmlMultipleMobile:xml_string5,
				    lostPropertyRegistrationId:'0',
				    isSyncFirstSyncDone:'N',
				    propDc:$scope.dist,
				    propPs:$scope.thanadist,
				    eqDc:'0',
				    eqPs:'0'
					
					};
					
					
					
/*for(i=0;i<= $scope.thanadatas.length;i++)
{
	// alert($scope.result.securityQuestionFirst);
	//  alert($scope.questions[i].nationalIdCd);
	//   alert($scope.questions[i].nationalIdType);
	if($scope.thanadist==$scope.thanadatas[i].policeStationCd)
	{
	//alert($scope.questions.nationalIdType);
	//var id=$scope.result.securityQuestionFirst;
	var thananame=$scope.thanadatas[i].policeStationName;
	//var userid=$scope.result.loginId;
	
	
	}
}*/
			
					 
					 
					var insertpera = JSON.stringify($scope.insertdata);
            //     alert(insertpera);
                    $http({
                        method: 'POST',
                        url: appurl+'/registerLostArticle',
                        data: insertpera,						
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                       // alert(JSON.stringify(serverResponse));
					  			 
							modal.hide();
					  $scope.regnum ={				
					langCd:6
					
					};
				//	alert($scope.country);
					var reg = JSON.stringify($scope.regnum);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/getPropertyRegNumber',
                        data: reg,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                 //     alert(JSON.stringify(serverResponse));
                        $scope.reg = serverResponse.propertyRegNumResponseBean;
						$scope.$apply();
						 
					
						// alert("Article Submitted Successfully");
						 var articlemsg="Your report has been submitted to "+tname+", "+dname+". Please note that this report is not subjected to any further investigation. Please take a print out of this report for your reference";
						 
						 alert(articlemsg);
						 $scope.regservice ={				
					propertyRegNumber:$scope.reg.propertyRegNumber
					
					};
				//	alert($scope.country);
					var servicedata = JSON.stringify($scope.regservice);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/getPsDistrict',
                        data: servicedata,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
               //      alert(JSON.stringify(serverResponse));
                         $scope.policestation = serverResponse.propertyRegNumResponseBean;
					//	 alert($scope.policestation.ps);
						  $scope.$apply();
						   var htmldata ='<div class="container">';
htmldata +='<div class="page-header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class="img-responsive center-block" src="images/banner1.jpg" width="391" height="112" /></div><div class="row text-center"><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;INFORMATION REPORT </h3><br><h4>IN RESPECT OF ARTICLE/DOCUMENT LOST IN:   '+$scope.ltlocation+'<br><br>Complaint ID: '+$scope.reg.propertyRegNumber+' </h4>    </div>    <hr>';
 htmldata +='   <div class="row" style="background-color:;">';
  htmldata +='  	<div class="col-sm-4">Date : '+cdate+'</div>';
  htmldata +='      <div class="col-sm-4">District Name :'+dname+' ,Police Station :'+tname+'</div>';
  htmldata +='   </div>';
 htmldata +='    <hr>';
 htmldata +='    <div class="table-responsive">';
  htmldata +='   		<table class="table">';
   htmldata +='      	<tr style="font-weight:bold;">';
   htmldata +='          	<td>1</td><td>Complaint Details :</td><td></td><td></td>';
   htmldata +='          </tr>';
  htmldata +='           <tr>';
  htmldata +='           	<td></td><td>Name of Person:</td><td>'+$scope.fullname+'</td><td></td>';
    htmldata +='         </tr>';
     htmldata +='         <tr><td></td><td>Mobile No:</td><td>'+mnum+'</td><td></td></tr>';
    htmldata +='         <tr>';
    htmldata +='         	<td></td><td>Address:</td><td>Country:India,State:'+statename+',District:'+disadd+',Police Station:'+psadd+',City:'+$scope.city+'</td><td></td>';
    htmldata +='         </tr>';

    htmldata +='         <tr style="font-weight:bold;"><td>2</td><td>User Item Details :</td><td></td><td></td></tr><tr>';
    htmldata +='         	<td></td><td>Item Number:</td><td>1</td><td></td>';
   htmldata +='          </tr>';
   htmldata +='           <tr>';
    htmldata +='         	<td></td><td>Item Name:  </td><td>'+itemname+'</td><td></td>';
   htmldata +='          </tr>';
  htmldata += extradata;
   
   
   htmldata +='          <tr>';
   htmldata +='          	<td></td><td>Mobile Number: </td><td>'+mnum+'</td><td></td>';
           htmldata +='  </tr>';
            htmldata +=' <tr>';
            htmldata +=' 	<td></td><td>Place of Missing:</td><td>'+$scope.ltlocation+'</td><td></td>';
            htmldata +=' </tr>';
            
		htmldata +=' 	<tr style="font-weight:bold;">';
       htmldata +='      <td>3</td><td>Occurrence Details :</td><td></td><td></td>';
      htmldata +='       </tr>';
     htmldata +='        <tr>';
     htmldata +='        	<td></td><td>Date and time of report :</td><td>'+cdate+'</td>';
     htmldata +='        </tr>';
     htmldata +='         <tr>';
     htmldata +='        	<td></td><td>Date and time of Lost :</td><td>'+datfrom+'</td>';
      htmldata +='       </tr>';
      htmldata +='       <tr style="font-weight:bold;">';
      htmldata +='       	<td>4</td><td>Any other Description :</td><td></td><td></td>';
      htmldata +='       </tr>          ';  
     htmldata +='    </table>    <hr>';
   htmldata +='  </div>';

 htmldata +='    <div class="row">';

htmldata +=' 		<h4>Disclaimer :</h4>';
htmldata +=' 		<ol>';
 htmldata +='        	<li>This is computer genrated slip. Signature is not allowed.</li>';
htmldata +=' 			<li>For Verification Please Visit the Web portal  www.mppolice.gov.in/verify_items</li>';
htmldata +=' 			<li>Authority issuing duplicate SIM may verify the proof of identity.MP Police is not liable for any identification.</li>';
htmldata +=' 		</ol>';
htmldata +='     </div><br><br>';
htmldata +=' </div>';
window.html2pdf.create(
            htmldata,
           // "~/Documents/test.pdf", // on iOS,
             "test.pdf" 
        );	
						 
						
						 
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure" + serverResponse);
                    });
					 
					   			 
					  		 $scope.$apply();
						 	$scope.dist="";
								$scope.thanadist="";
								$scope.ltdate="";
								$scope.lttime="";
							//	$scope.ltlocation="";
								$scope.articlename="";
								$scope.electronic="";
								$scope.ecost="";
								$scope.quantity="";
								$scope.manf="";
								$scope.imi="";
								$scope.isdn="";
								
								
								$scope.documentval="";
								$scope.ecostdoc="";
								$scope.dociden="";
							//	$scope.fullname="";
								$scope.gender="";
								$scope.mobile="";
								$scope.relative="";
								$scope.relativename="";
								//$scope.city="";
								$scope.country="";
								$scope.state="";
								$scope.distaddress="";
								$scope.psaddress="";
					   
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure" + serverResponse);
                    });
					   
					  
                       //  $scope.missingpersons = serverResponse.uidbResponseBean;
						//  $scope.$apply();
						  
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 
				 
					 }
					 
				 else 
					{
					$scope.showMsgs = true;
					}
				 }
				 
				
				  
            
            });
				
				
			
			
				module.controller('ComplaintReport', function ($scope, $http) {
                
             try {
                    
                //    var id = $scope.st; // Will return "value1"
				var id = 	window.localStorage["userid"];
			//	alert(id);
                   $scope.userdeatils ={
					loginId:id
					};
					
					var userpera = JSON.stringify($scope.userdeatils);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/userProfileDisplay',
                        data: userpera,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                     //    alert(JSON.stringify(serverResponse));
						$scope.users = serverResponse.userProfileResponseBean;	
						
                        $scope.fullname = $scope.users.firstName;
						 $scope.mobile = $scope.users.mobileNum;
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
             
			 
			 // call country webservice
					$scope.compnature={				
					langCd:99
					};
					var complnat = JSON.stringify($scope.compnature);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getComplaintNature',
                        data: complnat,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					// 	 alert(JSON.stringify(serverResponse));
                         $scope.complaintnatures = serverResponse.complaintNatureResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
			 
			 			
			 
					$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
					
					 $scope.choices = [{}];
					 $scope.addNewChoice = function() {
					var newItemNo = $scope.choices.length+1;
					$scope.choices.push({'id':'choice'+newItemNo});
				  };
					
				  $scope.removeChoice = function() {
					var lastItem = $scope.choices.length-1;
					$scope.choices.splice(lastItem);
				  };
				  
				  
				  
				  
				  
				//	alert(parameter_district);
				try {
						 
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;	
						  $scope.districtsnew = serverResponse.masterResponseBean;	
						 
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
				 
					
					
					 
					 
					
					
				 
					
					
					
					// call gender webservice
					$scope.sendparametegen ={				
					langCd:99
					};
					var peragen = JSON.stringify($scope.sendparametegen);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterGenderType',
                        data: peragen,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
						// alert(JSON.stringify(serverResponse));
                         $scope.genders = serverResponse.masterResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					
					// call country webservice
					$scope.sendparametecountry={				
					langCd:99
					};
					var country = JSON.stringify($scope.sendparametecountry);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterNationality',
                        data: country,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.countries = serverResponse.nationalityResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
			 
					
				 
					
				 
				 
				 
				 //state_webservice
				  $scope.statefunc = function () { 
				  if($scope.country==80)
				{
				 
					$scope.stateval ={				
					langCd:99
					
					};
				//	alert($scope.country);
					var parameter2 = JSON.stringify($scope.stateval);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterState',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                  //    alert(JSON.stringify(serverResponse));
                         $scope.states = serverResponse.stateResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure" + serverResponse);
                    });
				}
				 }
				 	$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				  
				//	alert(parameter_district);
				try {
						 
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//  alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;	
						  $scope.districtsnew = serverResponse.masterResponseBean;	
						 
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
				 	 $scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.distaddress
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                    //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 
				  $scope.thanaagnew = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                    //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatas2 = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 $scope.lostsendcomp = function (form) {
					 
					 if ($scope[form].$valid) 
				{
					 
					 
					 
					 
					 var uid= window.localStorage["userid"];
				//	 alert('hi');
					 	
				//	var uid= window.localStorage["userid"];
				//	 alert(uid);
				
					function getFormattedDate(date)
					{
					var year = date.getFullYear();
					var month = (1 + date.getMonth()).toString();
					month = month.length > 1 ? month : '0' + month;
					var day = date.getDate().toString();
					day = day.length > 1 ? day : '0' + day;
					return year + '-' + month + '-' + day;
					}
					
					
					
					
						var datfrom = getFormattedDate($scope.ltdate);
						
					 	datfrom = datfrom + ' '+'00:00:00';
						
						var datto = getFormattedDate($scope.lttime);
						
					 	datto = datto + ' '+'00:00:00';
						
						
						var currentTime = new Date();
						
						 


   							function getFormattedDatenew(date)
					{
					var year = date.getFullYear();
					var month = (1 + date.getMonth()).toString();
					month = month.length > 1 ? month : '0' + month;
					var day = date.getDate().toString();
					day = day.length > 1 ? day : '0' + day;
					
					var hour = date.getHours();
					var minute = date.getMinutes();
					var second  =  date.getSeconds();
					var amPM = (hour > 11) ? "pm" : "am";
					if(hour > 12) {
					hour -= 12;
					} else if(hour == 0) {
					hour = "12";
					}
					 else if(hour <10) {
					hour = "0"+hour;
					}
					if(minute < 10) {
					minute = "0" + minute;
					}
					return year + '-' + month + '-' + day+' '+hour+':'+minute+':'+second;
					}

					   var year = currentTime.getFullYear();
					   
					  var cdate  = getFormattedDatenew(currentTime);
					   
					   
					//   var cdate  = '2016-05-24 18:10:25';
					   
					   
					   
					 cdate = cdate ;

                 
//alert(cdate);
  
 

var xml_string1 ='<ROOT> ';
xml_string1 +='<ADDRESS ADDRESSCD="1" LANGCD="6" PERSONCODE="1" ';
xml_string1 +='ADDRTYPE="1" ADDRESSLINE1=" " ADDRESSLINE2=" " ';
xml_string1 +='ADDRESSLINE3="  " VILLAGE="Bhopal" TEHSIL=" " ';
xml_string1 +='COUNTRYCD="80" STATECD="'+$scope.state+'" DISTRICTCD="'+$scope.distaddress+'" ';
xml_string1 +='PSCD="'+$scope.psaddress+'" PINCODE="0" RECORDSTATUS="C" ';
xml_string1 +='RECORDCREATEDON="'+cdate+'" ';
xml_string1 +='RECORDCREATEDBY="'+uid+'"  ORIGINALRECORD="1" SAMEFORPERMANENT="Y" /> ';
xml_string1 +='</ROOT>' ;


//var xml_string_new1 = xml_string1.replace("#", "'");
 
 //var y= xml_string_new1.replace("$", "'");

//xml_string1 = xml_string.replace("$", "'");

//permanent address
 var xml_string2 ='<ROOT> ';
 xml_string2 +='<ADDRESS ADDRESSCD="1" LANGCD="6" ';
 xml_string2 +='PERSONCODE="1" ADDRTYPE="1" ADDRESSLINE1=" " ';
 xml_string2 +='ADDRESSLINE2=" " ADDRESSLINE3=" " ';
 xml_string2 +='VILLAGE="bhopal" TEHSIL="tahseel" COUNTRYCD="80" ';
 xml_string2 +='STATECD="'+$scope.state+'" DISTRICTCD="'+$scope.distaddress+'" PSCD="'+$scope.psaddress+'" ';
 xml_string2 +='PINCODE="0" RECORDSTATUS="C" ';
 xml_string2 +='RECORDCREATEDON="'+cdate+'" ';
 xml_string2 +='RECORDCREATEDBY="'+uid+'"  ORIGINALRECORD="1" ';
 xml_string2 +='SAMEFORPERMANENT="Y" /> ';
 xml_string2 +='</ROOT>';

 
 
	var xml_string3 ='<ROOT>  ';
	xml_string3 +='<ACCUSEDPERSONALINFO SNO="0" ACCUSEDSRNO="1" PERSONCODE="0" ';
	xml_string3 +='LANGCD="6" UIDNUM=" " PERSONTYPECD="0" FIRSTNAME="'+$scope.fname+'" ';
	xml_string3 +='MIDDLENAME="'+$scope.mname+'" LASTNAME="'+$scope.lname+'" MOBILE1="91" MOBILE2="'+$scope.amobile+'" ';
	xml_string3 +='TELEPHONE="91" RECORDSTATUS="0" ';
	xml_string3 +='RECORDCREATEDON="'+cdate+'" ';
	xml_string3 +='RECORDCREATEDBY="'+uid+'"  ORIGINALRECORD="1" ADDRESSCD="1" ';
	xml_string3 +='ADDRTYPE="1" COUNTRYCD="0" STATECD="0" DISTRICTCD="0" ';
	xml_string3 +='PSCD="0" PINCODE="0" SAMEFORPERMANENT="N" ADDRESSCDPERM="1" ';
	xml_string3 +='ADDRTYPEPERM="2" COUNTRYCDPERM="0" STATECDPERM="0" ';
	xml_string3 +='DISTRICTCDPERM="0" PSCDPERM="0" PINCODEPERM="0" /> ';
	xml_string3 +='</ROOT>';
  
  


		$scope.insertdata = {				
			 personCode:'1',
			 langCd:'6',
			 personTypeCode:'35',
			 uidNumber:' ', 
			 firstName:$scope.fullname,
			 middleName:' ',
			 lastName:' ',
			 relativeType:'',
			 relativeName:'',
			 dateOfBirth:' ',
			 mobileNum1:'91',
			 mobileNum2:$scope.mobile,
			 telephoneNum:'91',
			 emailId:' ',
			 recordStatus:'C',
			 recordCreatedOn:cdate,
			 recordCreatedBy:uid,
			 originalRecord:'1',
			 complaintRegNum:'1',
			 complaintLangCd:'6',
			 complSrNumber:'1',
			 complPersonCd:'1',
			 complYear:year,
			 complRegDate:cdate,
			 requisitionType:'N',
			 complNatureCd:$scope.complanittype,
			 receiptModeCd:'0',
			 complDescription:$scope.cdesc,
			 complRemarks:$scope.cremarkdesc,
			 incidentPlace:$scope.pincident,
			 incidentType:$scope.tincident,
			 incidentFromDate:datfrom,
			 incidentToDate:datto,
			 isPsKnown:'Y',
			 isDistrictKnown:'N',
			 isOfficeKnown:'N',
			 submitDistrictCd:$scope.dist,
			 submitPsCd:$scope.thanadist,
			 submitOfficeCd:'0',
			 complRecordStatus:'C',
			 complRecordCreatedOn:cdate,
			 complRecordCreatedBy:uid,
			 complOriginalRecord:'1',
			 informationTypeCd:'1',
			 stateCd:$scope.state,
			 xmlComplPresentAddress:xml_string1,
			 xmlComplPermanentAddress:xml_string2,
			 xmlComplFiles:'',	
			 xmlComplNationality:'',						 		 
			 nationalityCd:'80',
			 yearOfBirth:' ',
			 age:'0',
			 ageMonths:'0',
			 ageFrom:'0',
			 ageTo:'0',
			 xmlAccusedMultipleInfo:xml_string3
							
		};
			
					 
					 
					var insertpera = JSON.stringify($scope.insertdata);

            	//	alert(insertpera);
                    $http({
                        method: 'POST',
                        url: appurl+'/complaintRegistration',
                        data: insertpera,						
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					    //	alert(JSON.stringify(serverResponse));
                			
						
						 	var compdata = serverResponse.complaintRegistrationResponseBean;							 
						//	 alert(compdata.newRegistrationNum);
							alert("Complaint Submitted Successfully, Your Complaint No. is : "+compdata.newRegistrationNum);
								
								$scope.fullname="";
								$scope.complanittype="";
								$scope.mobile="";
								$scope.city="";
								$scope.country="";
								$scope.state="";
								$scope.distaddress="";
								$scope.psaddress="";
								$scope.fname="";
								$scope.mname="";
								$scope.lname="";
								
								
								$scope.amobile="";
								$scope.pincident="";
								$scope.tincident="";
								$scope.ltdate="";
								$scope.lttime="";
								$scope.dist="";
								$scope.thanadist="";
								$scope.cdesc="";
								$scope.cremarkdesc="";
								 
							/*myNavigator.pushPage('acknowledge.html', {
							animation: 'slide',
							compid:compdata.newRegistrationNum,
							comdate:cdate 
							});*/
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 
				 
					 
				 
				 
				 }
		
				else 
				{
				$scope.showMsgs = true;
				}
						 
				 }
				 
				
				  
            
            });
				
				
				 module.controller('ComplaintView', function ($scope,$http) {
					 var uid= window.localStorage["userid"];
			 
		 	$scope.opensearch = function (cond) {
				
					
					if(cond=="showdiv")
					{
						
					
					 document.getElementById("mseachform").style.display = "block"; 
					 document.getElementById("hdiv").style.visibility = "visible"; 
					 document.getElementById("sdiv").style.visibility = "hidden"; 
					}
					else
					{
					 document.getElementById("mseachform").style.display = "none"; 
					 document.getElementById("hdiv").style.visibility = "hidden"; 
					 document.getElementById("sdiv").style.visibility = "visible"; 
					}
                    
                }
				
			
					
				
				$scope.searchcomplaint = function (form) {
					if($scope[form].$valid) 
				{
				 modal.show();
					//alert($scope.datefrom);
					//alert($scope.dateo);
					
					
					if($scope.datefrom=='NULL')
					{
						 datfrom=$scope.datefrom;
						
					}
					else
					{
						function getFormattedDate(date)
						{
						var year = date.getFullYear();
						var month = (1 + date.getMonth()).toString();
						month = month.length > 1 ? month : '0' + month;
						var day = date.getDate().toString();
						day = day.length > 1 ? day : '0' + day;
						return year + '-' + month + '-' + day;
						}
						
						var datfrom = getFormattedDate($scope.datefrom);
						 datfrom = datfrom + ' 00:00:00';

						
					
					}
				
						
					//	alert(datfrom);
					//	alert(datto);
					//	var date = new Date($scope.dob);
//var  dob=date.getFullYear()  + '-'+ (date.getMonth() + 1) + '-'+ date.getDate() +' 00:00:00.000';
//alert(datfor);
					$scope.searchpera = {				
					complaintCd: $scope.cnum,
					complaintCdTmp: $scope.tcnum,
					firstName: $scope.fname,
					complaintDOB:$scope.datefrom,
					idType:0,
					idNum: '',
					langCd: 6,
					authorizedLoginId:uid,
					middleName :$scope.mname,
					lastName :$scope.lname,
					officeTypeCd :0,
					officeCd :0
					
					
					};
					
					var parameter = JSON.stringify($scope.searchpera);
              //   alert(parameter);
                    $http({
                        method: 'POST',
                        url: appurl+'/getListOfComplaint',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                      modal.hide();
						 //alert(JSON.stringify(serverResponse));
						if(serverResponse==null)
						{
						alert("Data not found");
						}
						else
						{
							$scope.missingpersons = serverResponse.listOfComplaintResponseBean;
							$scope.$apply();
							
							$scope.statusreg = {				
							complaintCd: $scope.cnum,							
							langCd: 6,
							authorizedLoginId:uid
							
							};
					
					var parameterreg = JSON.stringify($scope.statusreg);
							$http({
							method: 'POST',
							url: appurl+'/getComplaintStatus',
							data: parameterreg,
							headers: {
							"Content-Type": "application/json; charset=utf-8"
							}
							}).success(function (serverResponse, status, headers, config) { 
							
							//alert(JSON.stringify(serverResponse));
							$scope.recordstatus = serverResponse.complaintStatusResponseBean;
							
							
							 
							//	  modal.hide();
							
							}).error(function (serverResponse, status, headers, config) {
							alert("failure" + serverResponse);
							});
							
							document.getElementById("mseachform").style.display = "none"; 
							document.getElementById("hdiv").style.visibility = "hidden"; 
							document.getElementById("sdiv").style.visibility = "visible"; 	
							document.getElementById("displayid").style.visibility = "visible"; 	
							document.getElementById("displayid").style.display = "block";
						
						}
				   
                         
							 
					//	  modal.hide();
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
					
				}
					
				else
				{
				$scope.showMsgs = true;
				}
			 }
				 
				
				
			 
            });
				 
			
			
			
			
				 
		  module.directive('fileModel', ['$parse', function ($parse) {return {
           restrict: 'A',
           link: function(scope, element, attrs) {
              element.bind('change', function(){
											  
              $parse(attrs.fileModel).assign(scope,element[0].files)
                 scope.$apply();
              });
           }
        };
             }]).controller('CitizentipsController', ['$scope', '$http', function($scope,$http){
				 
				 
				$scope.xmldata=0;
				$scope.$apply();
				 $scope.fileLoaded = function (e) {
        var tgt = e.target || window.event.srcElement,
            files = tgt.files,
            fileReader;

        if (FileReader && files && files.length) {
            var fileReader = new FileReader();
            fileReader.onload = function () {

                $scope.loadedFile = fileReader.result;
                $scope.$apply();
				//alert( $scope.loadedFile);
				 $http({
                        method: 'POST',
                        url: appurl+'/fileUpload',
                        data: {uploadFile:$scope.loadedFile},
						 headers: {
                            "Content-Type": "application/json;"
                        }
                       
                    }).success(function (serverResponse, status, headers, config) { 
					   
					  		
                		//	alert(JSON.stringify(serverResponse));
							$scope.filedata = serverResponse;
							$scope.xmldata = 1;
							
							
						//	alert($scope.filedata.fileName);
						//	alert($scope.filedata.filePath);
						//	alert($scope.filedata.fileSize);
						//	var i = parseInt(Math.floor(Math.log($scope.filedata.fileSize) / Math.log(1024)));
							
							$scope.$apply();
							
							
						
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
            }
            fileReader.readAsDataURL(files[0]);
        } else {
            // Not supported
        }
    };

	
	
						
					
					try {
                    
                //    var id = $scope.st; // Will return "value1"
				var id = 	window.localStorage["userid"];
			//	alert(id);
                   $scope.userdeatils ={
					loginId:id
					};
					
					var userpera = JSON.stringify($scope.userdeatils);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/userProfileDisplay',
                        data: userpera,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
                     //    alert(JSON.stringify(serverResponse));
						$scope.users = serverResponse.userProfileResponseBean;	
						
                        $scope.fname = $scope.users.firstName;
						$scope.mname = $scope.users.middleName;
						$scope.lname = $scope.users.lastName;
						$scope.amobile = $scope.users.mobileNum;
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
             


			 // call country webservice
					$scope.compnature={				
					langCd:99
					};
					var complnat = JSON.stringify($scope.compnature);
					
					 
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getNatureOfInformation',
                        data: complnat,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					 	// alert(JSON.stringify(serverResponse));
                         $scope.infotypes = serverResponse.natureOfInfoResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					
					$scope.modeof={				
					langCd:99
					};
					var modeinfo = JSON.stringify($scope.modeof);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getModeOfInformation',
                        data: modeinfo,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					 //	 alert(JSON.stringify(serverResponse));
                         $scope.modeofinfo = serverResponse.informationModeResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
			 
			 			
			 
					$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				
				  
				  
				  
				  
				  
				//	alert(parameter_district);
				try {
						 
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;	
						  $scope.districtsnew = serverResponse.masterResponseBean;	
						 
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
				
					
					
					
					// call country webservice
					$scope.sendparametecountry={				
					langCd:99
					};
					var country = JSON.stringify($scope.sendparametecountry);
					
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterNationality',
                        data: country,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	 alert(JSON.stringify(serverResponse));
                         $scope.countries = serverResponse.nationalityResponseBean;						
                         $scope.$apply();
                       
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
			 
					
				 
					
				 
				 
				 
				 //state_webservice
				  $scope.statefunc = function () { 
				  if($scope.country==80)
				{
				 
					$scope.stateval ={				
					langCd:99
					
					};
				//	alert($scope.country);
					var parameter2 = JSON.stringify($scope.stateval);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterState',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                  //    alert(JSON.stringify(serverResponse));
                         $scope.states = serverResponse.stateResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                      //  alert("failure" + serverResponse);
                    });
					
				}
				 }
				 
				 
				 
				 
				 	$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				  
				//	alert(parameter_district);
				try {
						 
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//  alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;	
						  $scope.districtsnew = serverResponse.masterResponseBean;	
						 
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
				 	 $scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.distaddress
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                    //  alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 
				 
				  $scope.thananew = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.sdistaddress
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                    //  alert(JSON.stringify(serverResponse));
                         $scope.sthanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 
				  $scope.thananew1 = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                    //  alert(JSON.stringify(serverResponse));
                         $scope.newdistrict = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                     //   alert("failure" + serverResponse);
                    });
				 }
				 
				 
				 
				 $scope.sendcitizentips = function (form) {
					 
				 if ($scope[form].$valid) 
					 {	
					 var uid= window.localStorage["userid"];
					 	
					 function getFormattedDatenew(date)
					{
					var year = date.getFullYear();
					var month = (1 + date.getMonth()).toString();
					month = month.length > 1 ? month : '0' + month;
					var day = date.getDate().toString();
					day = day.length > 1 ? day : '0' + day;
					
					var hour = date.getHours();
					var minute = date.getMinutes();
					var second  =  date.getSeconds();
					var amPM = (hour > 11) ? "pm" : "am";
					if(hour > 12) {
					hour -= 12;
					} else if(hour == 0) {
					hour = "12";
					}
					 else if(hour <10) {
					hour = "0"+hour;
					}
					if(minute < 10) {
					minute = "0" + minute;
					}
					return year + '-' + month + '-' + day+' '+hour+':'+minute+':'+second;
					}

					   var currentTime = new Date();
					   
					  var cdate  = getFormattedDatenew(currentTime);
					  
					  
					
					  
  if($scope.uid==undefined)
{
$scope.uid="";

}

if($scope.hon==undefined)
{
	$scope.hon="";

}
if($scope.street==undefined)
{
	$scope.street="";

}
if($scope.area==undefined)
{
	$scope.area="";

}


if($scope.tb==undefined)
{
	$scope.tb="";

}

if($scope.city==undefined)
{
	$scope.city="";

}
if($scope.country==undefined)
{
	$scope.country="";

}
if($scope.state==undefined)
{
	$scope.state="";

}
if($scope.distaddress==undefined)
{
	$scope.distaddress="";

}
if($scope.psaddress==undefined)
{
	$scope.psaddress="";

}



if($scope.uid1==undefined)
{
	$scope.uid1="";

}

if($scope.hon1==undefined)
{
	$scope.hon1="";

}
if($scope.street1==undefined)
{
	$scope.street1="";

}
if($scope.area1==undefined)
{
	$scope.area="";

}


if($scope.tb1==undefined)
{
	$scope.tb1="";

}

if($scope.city1==undefined)
{
	$scope.city1="";

}
if($scope.scountry==undefined)
{
	$scope.scountry="";

}
if($scope.sstate==undefined)
{
	$scope.sstate="";

}
if($scope.sdistaddress==undefined)
{
	$scope.sdistaddress="";

}
if($scope.spsaddress==undefined)
{
	$scope.spsaddress="";

}


if($scope.sfname==undefined)
{
	$scope.sfname="";

}
if($scope.smname==undefined)
{
	$scope.smname="";

}
if($scope.slname==undefined)
{
	$scope.slname="";

}
if($scope.samobile==undefined)
{
	$scope.samobile="";

}					 
		// alert(cdate);
		 
	//	 alert($scope.samobile);
		

var xml_string1 ='<ROOT> ';
xml_string1 +='<CITIZENTIPINFORMERDETAILS PERSONCODE="0" LANGCD="6" ';
xml_string1 +='PERSONTYPECD="0" STATECD="'+$scope.state+'" DISTRICTCD="'+$scope.distaddress+'" PSID="'+$scope.psaddress+'" ';
xml_string1 +='FIRSTNAME="'+$scope.fname+'" MIDDLENAME="'+$scope.mname+'" LASTNAME="'+$scope.lname+'" ';
xml_string1 +='MOBILE1="91" MOBILE2="'+$scope.amobile+'" TELEPHONE1="91--" EMAIL1="NULL" ';
xml_string1 +='NATIONALITYCD="0" UIDNUM="'+$scope.uid+'" NATIONALIDTYPECD="0" ';
xml_string1 +='NATIONALIDNUM=" "  RECORDCREATEDON="'+cdate+'" ';
xml_string1 +='RECORDCREATEDBY="'+uid+'" ORIGINALRECORD="1" />  ';
xml_string1 +='</ROOT>';

//alert(xml_string1);
//var xml_string_new1 = xml_string1.replace("#", "'");
 
 //var y= xml_string_new1.replace("$", "'");

//xml_string1 = xml_string.replace("$", "'");

//permanent address
 var xml_string2 ='<ROOT> ';
 xml_string2 +='<CITIZENTIPINFORMERADDRESS ADDRESSCD="0" LANGCD="6" ';
 xml_string2 +='PERSONCODE="0" ADDRTYPE="'+$scope.hon+'" ADDRESSLINE1="'+$scope.hon+'" ';
 xml_string2 +='ADDRESSLINE2="'+$scope.street+'" ADDRESSLINE3="'+$scope.area+'" ';
 xml_string2 +='VILLAGE1="'+$scope.city+'" TEHSIL1="'+$scope.tb+'" COUNTRYCD="'+$scope.country+'" ';
 xml_string2 +='STATECD="'+$scope.state+'" DISTRICTCD="'+$scope.distaddress+'" PSCD="'+$scope.psaddress+'" ';
 xml_string2 +='PINCODE1="0" RECORDCREATEDON="'+cdate+'" ';
 xml_string2 +='RECORDCREATEDBY="'+uid+'" ORIGINALRECORD="1" /> ';
 xml_string2 +='</ROOT>';
 
// alert(xml_string2);
 
	var xml_string3 ='<ROOT> ';
	xml_string3 +='<CITIZENTIPSUSPECTDETAILS PERSONCODE="0" LANGCD="6" ';
	xml_string3 +='PERSONTYPECD="0" STATECD="'+$scope.sstate+'" DISTRICTCD="'+$scope.sdistaddress+'" PSID="'+$scope.spsaddress+'" ';
	xml_string3 +='FIRSTNAME="'+$scope.sfname+'" MIDDLENAME="'+$scope.smname+'" LASTNAME="'+$scope.slname+'" ';
	xml_string3 +='MOBILE1="91" MOBILE2="'+$scope.samobile+'" TELEPHONE1="91--" ';
	xml_string3 +='NATIONALITYCD="0" UIDNUM="'+$scope.uid1+'" NATIONALIDTYPECD="0"  ';
	xml_string3 +='PASSPORTISSUEDT=" " RECORDCREATEDON="'+cdate+'" ';
	xml_string3 +='RECORDCREATEDBY="'+uid+'" ORIGINALRECORD="1" /> ';
	xml_string3 +='</ROOT>';

//	alert(xml_string3);
	
	var xml_string4 ='<ROOT> ';
	xml_string4 +='<CITIZENTIPSUSPECTADDRESS ADDRESSCD="0" LANGCD="6" ';
	xml_string4 +='PERSONCODE="0" ADDRTYPE="1" ADDRESSLINE1="'+$scope.hon1+'" ';
	xml_string4 +='ADDRESSLINE2="'+$scope.street1+'" ADDRESSLINE3="'+$scope.area1+'" ';
	xml_string4 +='VILLAGE1="'+$scope.city1+'" TEHSIL1="'+$scope.tb1+'" COUNTRYCD="'+$scope.scountry+'" ';
	xml_string4 +='STATECD="'+$scope.sstate+'" DISTRICTCD="'+$scope.sdistaddress+'" PSCD="'+$scope.spsaddress+'" ';
	xml_string4 +='PINCODE1="0" RECORDCREATEDON="'+cdate+'" ';
	xml_string4 +='RECORDCREATEDBY="'+uid+'" ORIGINALRECORD="1" /> ';
	xml_string4 +='</ROOT>';
	
	if($scope.xmldata==1)
	{

var xml_string5 ='<ROOT> ';
xml_string5 +='<CITIZENTIPFILES FILEPATH="'+$scope.filedata.filePath+'" ';
xml_string5 +='TIPFILESRNO="0" LANGCD="6" CITIZENTIPSRNO="0" FILESRNO="1" FILETYPECD="1" ';
xml_string5 +='FILEBELONGSTO="Citizen Tip" FILENAME="'+$scope.filedata.fileName+'" ';
xml_string5 +='FILEDESC="description" FILESIZE="'+$scope.filedata.fileSize+'" ';
xml_string5 +='RECORDCREATEDON="'+cdate+'" ';
xml_string5 +='ORIGINALRECORD="1" FILESUBTYPECD="14" /> ';
xml_string5 +='</ROOT>';
	}
	else
	{
		xml_string5='';
	}

		$scope.insertdata = {
			langCd:'6',
			assignedStateCd:'21',
			assignedDistrictCd:$scope.dist,
			assignedPsCd:$scope.thanadist,   
			assignedOfficeCd:'0',
			informationDec:$scope.information,
			infoModeCd:$scope.moi,
			anyDocUploaded:' ',
			isPsKnown:'Yes',
			isDistrictKnown:'Yes',
			recordStatus:'Created',
			recordCreatedBy:uid,			
			originalRecord:'1',
			natureOfInfo:$scope.toi,
			xmlCitizenTipUploadDocuments:xml_string5,
			xmlCitizenTipInfoDetails:xml_string1,
			xmlCitizenTipInfoAddress:xml_string2,
			xmlCitizenTipSuspectDetails:xml_string3,
			xmlCitizenTipSuspectAddress:xml_string4,
			base64data:$scope.loadedFile,
			imgDefault:$scope.xmldata
		};
			
					 
					 
					var insertpera = JSON.stringify($scope.insertdata);

            //	 alert(insertpera);
		
			
			
			 
                    $http({
                        method: 'POST',
                        url: appurl+'/citizenTipRegistration',
                        data: insertpera,						
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					 //  	 alert(JSON.stringify(serverResponse));
					//	  $scope.tipnumber = serverResponse.citizenTipsResponseBean;
						  var compdata = serverResponse.citizenTipResponseBean;
						  
						 
                			alert("Incident Submitted Successfully,Registration number is:"+compdata.citizenTipRegNum);
							
								$scope.uid="";
								$scope.toi="";
								$scope.hon="";
								$scope.street="";
								$scope.area="";
								$scope.tb="";
								$scope.city="";
								$scope.country="";
								$scope.state="";
								$scope.distaddress="";
								$scope.psaddress="";
								$scope.uid1="";
								
								
								$scope.sfname="";
								$scope.smname="";
								$scope.slname="";
								$scope.samobile="";
								$scope.hon1="";
								$scope.street1="";
								$scope.area1="";
								$scope.tb1="";
								$scope.city1="";
								$scope.scountry="";
								$scope.sstate="";
								$scope.sdistaddress="";
								$scope.spsaddress="";
								
								$scope.moi="";
								$scope.information="";
								$scope.dist="";
								$scope.thanadist="";
								$scope.fileval="";
					   
						 
							
							
							
							
							
						
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				   

				 
				 }
				else
				{
				 $scope.showMsgs = true;
				}
					 
				 }
				 
				
				  
            
          }]);
			 
			
			 module.controller('testingcontroller', function ($scope,$http,$filter) {
															  
		function getFormattedDate(date)
					{
					var year = date.getFullYear();
					var month = (1 + date.getMonth()).toString();
					month = month.length > 1 ? month : '0' + month;
					var day = date.getDate().toString();
					day = day.length > 1 ? day : '0' + day;
					return year + '-' + month + '-' + day;
					}
					function format_time(date_obj) {
					// formats a javascript Date object into a 12h AM/PM time string
					var hour = date_obj.getHours();
					var minute = date_obj.getMinutes();
					var second  =  '00';
					var amPM = (hour > 11) ? "pm" : "am";
					  if(hour <10) {
					hour = "0"+hour;
					}
					if(minute < 10) {
					minute = "0" + minute;
					}
					return hour + ":" + minute + ":"+second;
					}
					
					var currentTime = new Date();
					
					alert(currentTime);
				//	currentTime.setTimezone("Asia/Jakarta");
					
					var d = getFormattedDate(currentTime);
					var t = format_time(currentTime)
					cdate = d+' '+t;
					alert(cdate);
					  
					  
					  
            });
			 
			 
			 
			  module.controller('scrbaddressController', function ($scope,$http,$window) {
		 			
					$scope.redirectTolcoation = function () {
						
                
				       $window.open('http://www.mppolice.gov.in/', '_blank');
				}
										
										
										
			 
            });
			  
			  module.controller('SeizedVehicleController', function ($scope, $http) {
                
                 $scope.open = function (id1,id2) {
					// alert(id1+id2);
                    myNavigator.pushPage('seizedvehicleview.html', {
                        animation: 'slide',
                        per1: id1,
						per2:id2
                    });
                }
				
				
					$scope.opensearch = function (cond) {
					
					if(cond=="showdiv")
					{
						
					
					 document.getElementById("mseachform").style.display = "block"; 
					 document.getElementById("hdiv").style.visibility = "visible"; 
					 document.getElementById("sdiv").style.visibility = "hidden"; 
					}
					else
					{
					 document.getElementById("mseachform").style.display = "none"; 
					 document.getElementById("hdiv").style.visibility = "hidden"; 
					 document.getElementById("sdiv").style.visibility = "visible"; 
					}
                    
                }
				
					$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					 //	 alert(JSON.stringify(serverResponse));
                         $scope.districts = serverResponse.masterResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					 
					$scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                       // alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
				 
				 
				 $scope.vehicletype ={				
					langCd:99 
					};
					
					var parameter_vehicletype = JSON.stringify($scope.vehicletype);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getAutomobileType',
                        data: parameter_vehicletype,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					 	 //alert(JSON.stringify(serverResponse));
                         $scope.vehicletypes = serverResponse.automobileTypeResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					$scope.vehiclemake = function () { 
				 
					$scope.vmake ={				
					langCd:99,
					mvMakeCd:$scope.vtype					 
					};
					
					var makevehicletype = JSON.stringify($scope.vmake);
				//	alert(makevehicletype);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/getAutomobileMake',
                        data: makevehicletype,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                  //     alert(JSON.stringify(serverResponse));
                         $scope.vmaketypes = serverResponse.automobileMakeResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
					
					
					$scope.vehiclemade = function () { 
				 
					$scope.vmodeltype ={				
					langCd:99,
					mvMakeCd:$scope.make,
					mvMakeTypeCd:$scope.vtype	
					};
					
					var maodelvehicletype = JSON.stringify($scope.vmodeltype);
					//alert(maodelvehicletype);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/getAutomobileModel',
                        data: maodelvehicletype,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                      //  alert(JSON.stringify(serverResponse));
                         $scope.vmodels = serverResponse.automobileModelResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
					
				
				$scope.searchseized = function (form) {
				var valid=0;
		
	
						function getFormattedDate(date)
						{
						var year = date.getFullYear();
						var month = (1 + date.getMonth()).toString();
						month = month.length > 1 ? month : '0' + month;
						var day = date.getDate().toString();
						day = day.length > 1 ? day : '0' + day;
						return year + '-' + month + '-' + day;
						}
						
						
						if($scope.datefrom==undefined)
					{
						
						 valid+=1;
						
					
					}
					
					
					if($scope.dateo==undefined)
					{
						
						
						 valid+=1;
					
					}
					
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.thanadist==undefined)
					{
					 valid+=1;
					
					}
					if($scope.vtype==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.make==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.vmodel==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.engno==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.regno==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.chno==undefined)
					{
					
					 valid+=1;
					
					}
					if(valid==9)
					{
						alert("you must fill in at least one field");
						return false;
					}

					if($scope[form].$valid) 
						 {
						
						
						//modal.show();
						//alert('hi');
						
						
						
									//	alert(valid);
											
						if($scope.datefrom==undefined)
					{
						datfrom='1900-01-01 00:00:00';
						
						
					
					}
					else
					{
						
						var datfrom = getFormattedDate($scope.datefrom);
						 datfrom = datfrom + ' 00:00:00';

						
						
					}
					
					if($scope.dateo==undefined)
					{
					//	alert($scope.dateo);
						datto='9999-01-01 00:00:00';
						
					
					}
					else
					{
						
						
						var datto = getFormattedDate($scope.dateo);
						datto = datto + ' 00:00:00';
					}
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					$scope.dist=0;
					
					
					}
					
					if($scope.thanadist==undefined)
					{
					$scope.thanadist=0;
					
					}
					if($scope.vtype==undefined)
					{
					$scope.vtype=0;
					
					
					}
					if($scope.make==undefined)
					{
					$scope.make=0;
					 
					
					}
					
					if($scope.vmodel==undefined)
					{
					$scope.vmodel=0;
					
					
					}
					if($scope.engno==undefined)
					{
					$scope.engno="";
					
					
					}
					
					if($scope.regno==undefined)
					{
					$scope.regno="";
					
					}
					if($scope.chno==undefined)
					{
					$scope.chno="";
					 
					
					}
					
					
					
					 
						 modal.show();
	 		           
						$scope.searchpera = {				
						policeStationCd: $scope.thanadist,
						districtCd: $scope.dist,
						veichalType: $scope.vtype,
						veichalMake:$scope.make,
						veichalModel:$scope.vmodel,						
						startDate: datfrom,
						endDate: datto,
						engineno:$scope.engno,
						registrationNo:$scope.regno,
						chasisNo:$scope.chno
						};
						 
						var parameter = JSON.stringify($scope.searchpera);
				//	 alert(parameter);
						$http({
							method: 'POST',
							url: appurl+'/seizedVeichalList',
							data: parameter,
							headers: {
								"Content-Type": "application/json; charset=utf-8"
							}
						}).success(function (serverResponse, status, headers, config) { 
						//   alert(JSON.stringify(serverResponse));
						   modal.hide();
						   if(serverResponse==null)
						   {
							  
							   alert("Data not found");
						   }
						   else
						   {
							
							 	$scope.seizedadta = serverResponse.seizedVeichalResponseBean;
							if($scope.seizedadta.length>0)
							{
								$scope.seizedadta = serverResponse.seizedVeichalResponseBean;
								 $scope.$apply();
							
						
							
							document.getElementById("mseachform").style.display = "none"; 
							document.getElementById("hdiv").style.visibility = "hidden"; 
							document.getElementById("sdiv").style.visibility = "visible"; 	
							}
							else
							{
									var JSONObject = serverResponse.seizedVeichalResponseBean;
							var jsonObjArray = []; // = new Array();
							jsonObjArray.push(JSONObject);
							 $scope.seizedadta =jsonObjArray;
							$scope.$apply();
							document.getElementById("mseachform").style.display = "none"; 
							document.getElementById("hdiv").style.visibility = "hidden"; 
							document.getElementById("sdiv").style.visibility = "visible";
								
							} 
								 
						   }
 							 
							// alert($scope.seizedadta);
							
					
													 
						}).error(function (serverResponse, status, headers, config) {
							alert("failure" + serverResponse);
							 modal.hide();
						});
					
						}
						else
						{
							 $scope.showMsgs = true;
						}
				 
				
					}
					
					
            
				
            }); 
			  
			  
			  	 module.controller('SeizedVehicleViewController', function ($scope, $http) {
                
                try {
                    var page = myNavigator.getCurrentPage();
                    var sn = page.options.per1; // Will return "value1"
					var pr = page.options.per2; // Will return "value1"
					
					$scope.details = {
					seizureNum: sn,
					propRegNum: pr					
					};
					 
					var peradetails = JSON.stringify($scope.details);
					
				//	alert(peradetails);
					
                     $http({
                        method: 'POST',
                        url: appurl+'/seizedVeichalDetails',
                        data: peradetails,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					//  alert(JSON.stringify(serverResponse));
                        $scope.seizedvehicleDetails = serverResponse.automobileSeizedResponseBeanDetails;
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
            });
				 
				 
				   module.controller('TheftVehicleController', function ($scope, $http) {
                
                 $scope.open = function (id1) {
                    myNavigator.pushPage('theftvehicleview.html', {
                        animation: 'slide',
                        per1: id1
                    });
                }
				
				
					$scope.opensearch = function (cond) {
						
						
						
					
					if(cond=="showdiv")
					{
						
					
					 document.getElementById("mseachform").style.display = "block"; 
					 document.getElementById("hdiv").style.visibility = "visible"; 
					 document.getElementById("sdiv").style.visibility = "hidden"; 
					}
					else
					{
					 document.getElementById("mseachform").style.display = "none"; 
					 document.getElementById("hdiv").style.visibility = "hidden"; 
					 document.getElementById("sdiv").style.visibility = "visible"; 
					}
                    
                }
				
						$scope.sendparamete ={				
					langCd:99,
					stateCd:21
					};
					
					var parameter_district = JSON.stringify($scope.sendparamete);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/masterDistrictName',
                        data: parameter_district,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					 	 //alert(JSON.stringify(serverResponse));
						 $scope.districts = serverResponse.masterResponseBean;						
							 $scope.$apply();
						
						 
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					
					 
					$scope.thana = function () { 
				 
					$scope.sendparamete2 ={				
					langCd:99,
					districtCd:$scope.dist
					};
					
					var parameter2 = JSON.stringify($scope.sendparamete2);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/masterPoliceStationName',
                        data: parameter2,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                        //alert(JSON.stringify(serverResponse));
                         $scope.thanadatas = serverResponse.masterResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
				 
				 
				 $scope.vehicletype ={				
					langCd:99 
					};
					
					var parameter_vehicletype = JSON.stringify($scope.vehicletype);
				//	alert(parameter_district);
					 try {
                   $http({
                        method: 'POST',
                        url: appurl+'/getAutomobileType',
                        data: parameter_vehicletype,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					 	 //alert(JSON.stringify(serverResponse));
                         $scope.vehicletypes = serverResponse.automobileTypeResponseBean;						
                         $scope.$apply();
						
					   
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                }
				
					catch (e) {
						alert(e);
					}
					
					$scope.vehiclemake = function () { 
				 
					$scope.vmake ={				
					langCd:99,
					mvMakeCd:$scope.vtype					 
					};
					
					var makevehicletype = JSON.stringify($scope.vmake);
					//alert(makevehicletype);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/getAutomobileMake',
                        data: makevehicletype,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                      // alert(JSON.stringify(serverResponse));
                         $scope.vmaketypes = serverResponse.automobileMakeResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
					
					
					$scope.vehiclemade = function () { 
				 
					$scope.vmodeltype ={				
					langCd:99,
					mvMakeCd:$scope.make,
					mvMakeTypeCd:$scope.vtype	
					};
					
					var maodelvehicletype = JSON.stringify($scope.vmodeltype);
					//alert(maodelvehicletype);
                  
                    $http({
                        method: 'POST',
                        url: appurl+'/getAutomobileModel',
                        data: maodelvehicletype,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
                      //  alert(JSON.stringify(serverResponse));
                         $scope.vmodels = serverResponse.automobileModelResponseBean;
						  $scope.$apply();
						 
						 
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure" + serverResponse);
                    });
				 }
					
				
				$scope.searchseized = function (form) {
				var	valid=0;
			//	alert('hi');
					function getFormattedDate(date)
						{
						var year = date.getFullYear();
						var month = (1 + date.getMonth()).toString();
						month = month.length > 1 ? month : '0' + month;
						var day = date.getDate().toString();
						day = day.length > 1 ? day : '0' + day;
						return year + '-' + month + '-' + day;
						}
						
						
						if($scope.datefrom==undefined)
					{
						
						 valid+=1;
						
					
					}
					
					
					if($scope.dateo==undefined)
					{
						
						
						 valid+=1;
					
					}
					
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.thanadist==undefined)
					{
					$scope.thanadist=0;
					
					}
					if($scope.vtype==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.make==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.vmodel==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.engno==undefined)
					{
					
					 valid+=1;
					
					}
					
					if($scope.regno==undefined)
					{
					
					 valid+=1;
					
					}
					if($scope.chno==undefined)
					{
					
					 valid+=1;
					
					}
					if(valid==9)
					{
						alert("you must fill in at least one field");
						return false;
					}
				
					
						if($scope[form].$valid) 
						 {
							 
							 
						
							if($scope.datefrom==undefined)
					{
						datfrom='1900-01-01 00:00:00';
						
						
					
					}
					else
					{
						
						var datfrom = getFormattedDate($scope.datefrom);
						 datfrom = datfrom + ' 00:00:00';

						
						
					}
					
					if($scope.dateo==undefined)
					{
					//	alert($scope.dateo);
						datto='9999-01-01 00:00:00';
						
					
					}
					else
					{
						
						
						var datto = getFormattedDate($scope.dateo);
						datto = datto + ' 00:00:00';
					}
					
						 
					
					
					
					if($scope.dist==undefined)
					{
					$scope.dist=0;
					
					
					}
					
					if($scope.thanadist==undefined)
					{
					$scope.thanadist=0;
					
					}
					if($scope.vtype==undefined)
					{
					$scope.vtype=0;
					
					
					}
					if($scope.make==undefined)
					{
					$scope.make=0;
					 
					
					}
					
					if($scope.vmodel==undefined)
					{
					$scope.vmodel=0;
					
					
					}
					if($scope.engno==undefined)
					{
					$scope.engno="";
					
					
					}
					
					if($scope.regno==undefined)
					{
					$scope.regno="";
					
					}
					if($scope.chno==undefined)
					{
					$scope.chno="";
					 
					
					}
					
						
						modal.show();
					//alert($scope.datefrom);
					//alert($scope.dateo);
					
					
					
							
						// alert($scope.vmodel);
	 		           
						$scope.searchpera = {				
						psCode: $scope.thanadist,
						districtCd: $scope.dist,
						mvType: $scope.vtype,
						mvMake:$scope.make,
						mvModel:$scope.vmodel,
						engineNum:$scope.engno,
						registrationNum:$scope.regno,
						chasisNum:$scope.chno,
						startDate: datfrom,
						endDate: datto
						};
						 
						var parameter = JSON.stringify($scope.searchpera);
			//	  alert(parameter);
						$http({
							method: 'POST',
							url: appurl+'/robbedVeichalList',
							data: parameter,
							headers: {
								"Content-Type": "application/json; charset=utf-8"
							}
						}).success(function (serverResponse, status, headers, config) { 
						
						  modal.hide();
						  //$scope.seizedVeichalList="";
				//	  alert(JSON.stringify(serverResponse));
						if(serverResponse==null)
						{
						alert("Data not found");
						}
						else
						{
								
							
						 $scope.seizedVeichalList = serverResponse.robbedVeichalResponseBean;
							// alert( $scope.seizedVeichalList.length);
							if($scope.seizedVeichalList.length>0)
							{
								 $scope.seizedVeichalList = serverResponse.robbedVeichalResponseBean;
								 $scope.$apply();
							
						
							
							document.getElementById("mseachform").style.display = "none"; 
							document.getElementById("hdiv").style.visibility = "hidden"; 
							document.getElementById("sdiv").style.visibility = "visible"; 	
							}
							else
							{
									var JSONObject = serverResponse.robbedVeichalResponseBean;
							var jsonObjArray = []; // = new Array();
							jsonObjArray.push(JSONObject);
							 $scope.seizedVeichalList =jsonObjArray;
							$scope.$apply();
							document.getElementById("mseachform").style.display = "none"; 
							document.getElementById("hdiv").style.visibility = "hidden"; 
							document.getElementById("sdiv").style.visibility = "visible";
								
							}
					
							
						
						}
								 
													 
						}).error(function (serverResponse, status, headers, config) {
							alert("failure" + serverResponse);
							 modal.hide();
						});
					 
						
						}
						else
						{
							 $scope.showMsgs = true;
						}
				 
				
					}
					
					
            
				
            }); 
				   
		 module.controller('TheftVehicleViewController', function ($scope, $http) {
                
                try {
                    var page = myNavigator.getCurrentPage();
                    var sn = page.options.per1; // Will return "value1"
				 
					
					$scope.details = {
					firRegNum: sn 				
					};
					 
					var peradetails = JSON.stringify($scope.details);
					
					//alert(peradetails);
					
                     $http({
                        method: 'POST',
                        url: appurl+'/robbedVeichalDetails',
                        data: peradetails,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					  //alert(JSON.stringify(serverResponse));
                        $scope.seizedvehicleDetails = serverResponse.stolenVeichalResponseBean;
                        $scope.$apply();
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
                } catch (e) {
                    alert(e);
                }
            });		  
		 
		 
		 
			    //Forgot_password
				
			  module.controller('ForgotPasswordControllerJava', function ($scope, $http) {
			     
				
				
			   
                $scope.forgotPass = function (form) {
					
					
				 if ($scope[form].$valid) {	
				 
				 //	alert($scope.loginid);
					$scope.logindata = {				
					
					loginId: $scope.loginid			
					
					};
					
					var parameter = JSON.stringify($scope.logindata);
				//	alert(parameter);
                 
                     $http({
                        method: 'POST',
                        url: appurl+'/forgotPassword',
                        data: parameter,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {					
					//	 alert(JSON.stringify(serverResponse));
						 
						 if(serverResponse==null)
						{
						alert("Wrong Login Id");
						$scope.loginid="";
						}
						else
						{
                        $scope.result = serverResponse.forgotPasswordResponseBean;
						$scope.$apply();
						$scope.sendparamete2 ={				
						langCd:99
						};
					
					var parameter_squestions = JSON.stringify($scope.sendparamete2);
				//	alert(parameter_district);
					
                   $http({
                        method: 'POST',
                        url: appurl+'/masterSecurityQuestions',
                        data: parameter_squestions,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) {
					//	alert(JSON.stringify(serverResponse));
                         $scope.questions = serverResponse.masterResponseBean;	
						 $scope.$apply();
						 for(i=0;i<=$scope.questions.length;i++)
							   {
								  // alert($scope.result.securityQuestionFirst);
								 //  alert($scope.questions[i].nationalIdCd);
								 //   alert($scope.questions[i].nationalIdType);
								  if($scope.result.securityQuestionFirst==$scope.questions[i].nationalIdCd)
								  {
								  		//alert($scope.questions.nationalIdType);
										var id=$scope.result.securityQuestionFirst;
										var squestion=$scope.questions[i].nationalIdType;
										var userid=$scope.result.loginId;
										myNavigator.pushPage('forgotpasswordsend.html', {
										animation: 'slide',
										val1:id,
										val2:squestion,
										val3:userid
										});
										
								  }
							   }
                         
                       
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
               
			
						
						}
					   
                          
                    }).error(function (serverResponse, status, headers, config) {
                        alert("Connection Problem");
						$scope.loginid="";
						$scope.password="";
                    });
					 
					
				 }
				 else
				 {
				 	 $scope.showMsgs = true;
				 }
                }
            });
			  
			  
			  
			  
			  
			  
			    module.controller('ForgotPasswordSendControllerJava', function ($scope, $http) {
																			
				
				
				try {
                    var page = myNavigator.getCurrentPage();
                    var per1 = page.options.val1; // Will return "value1"
					var per2 = page.options.val2; // Will return "value2"
					var per3 = page.options.val3; // Will return "value3"
					
					//alert(per1+per2+per3);
					$scope.qid = per1;
					$scope.question = per2;
					$scope.userid = per3;					
					
					$scope.security = per1;
					$scope.loginid = per3;
					
					
                   	$scope.$apply();
                } catch (e) {
                    alert(e);
                }
				
				 $scope.resetPassword = function (form) {
				 if ($scope[form].$valid) {	
                  
				 
                    $scope.details = {
					loginId: $scope.loginid,
					securityQuestionId:$scope.security,
					securityQuestionAns: $scope.answer,
					newPassword: $scope.password
					
					};
					 
					var datadetails = JSON.stringify($scope.details);
			//		alert(datadetails);
					 $http({
                        method: 'POST',
                        url: appurl+'/forgotCheckPassword',
                        data: datadetails,
                        headers: {
                            "Content-Type": "application/json; charset=utf-8"
                        }
                    }).success(function (serverResponse, status, headers, config) { 
					//  alert(JSON.stringify(serverResponse));
                        $scope.fpassword = serverResponse.forgotPasswordCheckResponseBean;
					//	alert($scope.fpassword.mobileNo);
						if($scope.fpassword.bStatus=="true")
						{
							alert("Your changed password has been sent to your registered mobile number.");
									var sms="Updated password of Citizen App is:"+$scope.password;
								var url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=48e1745ebcfcdc80bcc238ec2ce96ac&message="+sms+"&senderId=dddddd&routeId=1&mobileNos="+$scope.fpassword.mobileNo+"&smsContentType=english"
								
									
									var xhttp = new XMLHttpRequest();
									xhttp.onreadystatechange = function() {
									if (xhttp.readyState == 4 && xhttp.status == 200) {
									
									}
									};
									xhttp.open("GET", url, true);
									xhttp.send();
							
							window.location.reload(true);
							$scope.$apply();
						}
						else
						{
							alert("You have entered wrong security answer");
						}
                        
                        
                    }).error(function (serverResponse, status, headers, config) {
                        alert("failure");
                    });
				 }
				 else
				 {
				 	 $scope.showMsgs = true;
				 }
                }
			
				
				});
				
				
				
				
				 module.controller('ContactController', function ($scope,$http) {
			
					
			 
            });	 